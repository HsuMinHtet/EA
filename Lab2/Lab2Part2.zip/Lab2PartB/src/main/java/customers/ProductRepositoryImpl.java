package customers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ProductRepositoryImpl implements ProductRepository {
	
	@Autowired
    private Logger logger;


    @Override
    public void save(Product product) {
        System.out.println("Product Repository: saving product " + product.getName());
        logger.log("Product is saved in the DB: " + product.getName());
    }

}
