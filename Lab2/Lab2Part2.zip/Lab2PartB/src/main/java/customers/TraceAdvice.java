package customers;

import java.time.LocalDateTime;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StopWatch;

@Aspect
@Configuration
public class TraceAdvice {
	@Before("execution(* customers.EmailSender.*(..)) && args(email,message)")
	public void tracebeforemethod(JoinPoint joinpoint, String email, String message) {
		System.out.println(LocalDateTime.now() + " method= " + joinpoint.getSignature().getName() + " address= " + email
				+ " message= " + message);
	}

	@After("execution(* customers.EmailSender.sendEmail(..)) && args(email,message)")
	public void traceaftermethod(JoinPoint joinpoint, String email, String message) {
		EmailSender emailSender = (EmailSender) joinpoint.getTarget();
		System.out.println(LocalDateTime.now() + " method= " + joinpoint.getSignature().getName() + " address= " + email
				+ " message= " + message + " outgoing mail server " + emailSender.getOutgoingMailServer());
	}

	

}
