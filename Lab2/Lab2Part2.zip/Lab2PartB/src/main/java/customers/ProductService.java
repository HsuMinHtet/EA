package customers;

public interface ProductService {

    void saveProduct(String id, String name, String description, double price);
    
}