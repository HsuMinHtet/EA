package bank.service.aop;


import java.time.LocalDateTime;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import bank.integration.logging.Logger;

@Aspect
@Configuration
public class JMSLogAdvice {
	
	@Autowired
	private Logger logger;
	
	@Before("execution(* bank.integration.jms.JMSSender.sendJMSMessage(..)) && args(text)")
	public void logJMSMessage(JoinPoint joinpoint, String text) {
		logger.log(" method= " + joinpoint.getSignature().getName()+" Text : "+ text);
	}


}
