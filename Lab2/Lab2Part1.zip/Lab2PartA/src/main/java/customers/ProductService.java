package customers;

public interface ProductService {

    void addProduct(String id, String name, String description, double price);
    
}