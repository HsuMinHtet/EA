package customers;

public @interface SpringBootApplication {

}
