package customers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

@Repository
@Profile("One")
public class CustomerRepositoryImpl1 implements CustomerRepository {
	
	@Autowired
	private Logger logger;

	public void save(Customer customer) {
		System.out.println("CustomerRepository: saving customer One" + customer.getName());
		logger.log("Customer is saved in the DB: " + customer.getName());
	}

}
