package customers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
    ProductRepository productRepository;

//    public void setCustomerRepository(ProductRepository prodRepo) {
//        this.productRepository = prodRepo;
//    }

    @Override
    public void addProduct(String id, String name, String description, double price) {
        Product product = new Product(id, name, description, price);
        productRepository.save(product);
    }

}
