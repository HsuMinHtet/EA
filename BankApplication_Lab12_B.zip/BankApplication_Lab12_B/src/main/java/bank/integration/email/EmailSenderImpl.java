package bank.integration.email;

import bank.domain.TraceRecord;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

@Service
public class EmailSenderImpl implements EmailSender{
    @Override
    public void sendEmail(String message) {
        System.out.print("Email sending for TraceRecord");
    }
    @EventListener
    @Override
    public void sendEmailwithLister(TraceRecord traceRecord) {
         System.out.print("<<<<<Email sending for TraceRecord>>>>");
    }
}
