package bank.integration.email;

import bank.domain.TraceRecord;
import org.springframework.stereotype.Service;

public interface EmailSender {
    void sendEmail(String message);
    void sendEmailwithLister(TraceRecord traceRecord);
}
