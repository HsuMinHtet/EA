package bank.integration.jms;

import bank.domain.Account;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.stereotype.Service;
import org.springframework.jms.core.JmsTemplate;

@Service
//@EnableJms
public class JMSSenderImpl implements JMSSender{
	//@Autowired
	//JmsTemplate jmsTemplate;
	public void sendJMSMessage (String text){
		System.out.println("JMSSender: sending JMS message ="+text);

		//Account account = new Account("Frank", "Brown");
		//convert person to JSON string
		ObjectMapper objectMapper = new ObjectMapper();
		//String personAsString = objectMapper.writeValueAsString(person);

		System.out.println("Sending a JMS message:" + text);
		//jmsTemplate.convertAndSend("BankApplication",text);
	}

}
