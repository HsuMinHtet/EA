package bank.repository;

import bank.domain.TraceRecord;
import jdk.jfr.Registered;
import org.springframework.context.event.EventListener;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface TraceRecordRepository extends JpaRepository<TraceRecord,Long> {
    @EventListener
    default void saveTraceRecord(TraceRecord traceRecord){
        save(traceRecord);
        //System.out.println("from TraceRepository");
    }

}
