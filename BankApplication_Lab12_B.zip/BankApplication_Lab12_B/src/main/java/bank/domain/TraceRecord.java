package bank.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class TraceRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private LocalDateTime date;
    @ManyToOne
    private Account accountNumber;
    private String operation;

    private double amount;

    public TraceRecord(LocalDateTime date, Account accountNumber, String operation, double amount) {
        this.date = date;
        this.accountNumber = accountNumber;
        this.operation = operation;
        this.amount = amount;
    }

    public TraceRecord() {
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public Account getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(Account accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public Long getId() {
        return id;
    }
}
