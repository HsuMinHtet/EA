package bank.service.aop;

import bank.domain.Account;
import bank.domain.TraceRecord;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;

@Aspect
@Configuration
public class TraceRecordAdvice {
   @Autowired
    ApplicationEventPublisher publisher;

    @AfterReturning(pointcut = "execution(* bank.service.*.*(..)) && args(accountNumber,amount)")
    public void traceAfterDepositWithdraw(JoinPoint joinpoint, Long accountNumber, double amount) {
        System.out.println("In traceAfterDepositWithdraw");
        publisher.publishEvent(new TraceRecord(LocalDateTime.now(),new Account(accountNumber),joinpoint.getSignature().getName(),amount));
    }

    @AfterReturning(pointcut = "execution(* bank.service.AccountService.transferFunds(..)) && args(fromAccountNumber, toAccountNumber, amount, description)")
    public void traceAfterTransfer(JoinPoint joinpoint, long fromAccountNumber, long toAccountNumber, double amount, String description) {
        publisher.publishEvent(new TraceRecord(LocalDateTime.now(),new Account(fromAccountNumber),joinpoint.getSignature().getName(),amount));
        publisher.publishEvent(new TraceRecord(LocalDateTime.now(),new Account(toAccountNumber),joinpoint.getSignature().getName(),amount));
    }

}
