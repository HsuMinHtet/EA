package bank.dto;


import java.io.Serializable;

public class AccountCreateDTO implements Serializable {
    private long accountnumber;
    private String name;

    public AccountCreateDTO(long accountnumber, String name) {
        this.accountnumber = accountnumber;
        this.name = name;
    }

    public long getAccountnumber() {
        return accountnumber;
    }

    public void setAccountnumber(long accountnumber) {
        this.accountnumber = accountnumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
