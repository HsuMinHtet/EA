package bank.Controller;

import bank.domain.Account;
import bank.dto.AccountDepositWithdraw;
import bank.dto.AccountTransferFunds;
import bank.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@CrossOrigin
public class AccountController {
    @Autowired
    AccountService accountService;

    @PostMapping("/accounts")
    public ResponseEntity<?> createAccount(@RequestBody Account account){
        System.out.println("At CreateAccount controller ");
        return new ResponseEntity<Account>(accountService.createAccount(account.getAccountNumber(), account.getCustomer().getName()), HttpStatus.OK);
    }
    @GetMapping("/accounts/{accountNumber}")
    public ResponseEntity<?> getAccount(@PathVariable long accountNumber){
        System.out.println("At getAccount controller ");
        return new ResponseEntity<Account>(accountService.getAccount(accountNumber), HttpStatus.OK);
    }
    @GetMapping("/accounts")
    public ResponseEntity<?> getAllAccounts(){
        System.out.println("At getAccount controller ");
        return new ResponseEntity<Collection<Account>>(accountService.getAllAccounts(), HttpStatus.OK);
    }
    @PostMapping("accounts/{accountNumber}/deposit")
    public ResponseEntity<?> deposit (@PathVariable long accountNumber, @RequestBody AccountDepositWithdraw a){
        if(a.getCurrency().equals("US")){
            accountService.deposit(accountNumber, a.getAmount());
        }else{
            accountService.depositEuros(accountNumber,a.getAmount());
        }
        return new ResponseEntity<Account>(accountService.getAccount(accountNumber), HttpStatus.OK);
    }
    @PostMapping("accounts/{accountNumber}/withdraw")
    public ResponseEntity<?> withdraw (@PathVariable long accountNumber, @RequestBody AccountDepositWithdraw a){
        if(a.getCurrency().equals("US")){
            accountService.withdraw(accountNumber, a.getAmount());
        }else{
            accountService.withdrawEuros(accountNumber,a.getAmount());
        }
        return new ResponseEntity<Account>(accountService.getAccount(accountNumber), HttpStatus.OK);
    }
    @PostMapping("accounts/{accountNumber}/transfer")
    public ResponseEntity<?> transferFunds(@RequestBody AccountTransferFunds a){
        accountService.transferFunds(a.getFromAccountNumber(),a.getToAccountNumber(),a.getAmount(),a.getDescription());
       // System.out.println(a.getFromAccountNumber()+"and"+a.getToAccountNumber()+"and"+a.getAmount()+"and"+a.getDescription());
        return new ResponseEntity<Account>(accountService.getAccount(a.getFromAccountNumber()), HttpStatus.OK);
    }

}
