package mvc.repository;
import java.util.*;
import mvc.domain.Book;
import mvc.dto.BookResponse;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BookRepository extends JpaRepository<Book,Integer> {
    Book findByIsbn(String isbn);
    List<Book> findByAuthor(String author);
}
