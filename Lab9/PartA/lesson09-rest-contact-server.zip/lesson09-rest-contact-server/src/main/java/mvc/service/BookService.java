package mvc.service;

import mvc.domain.Book;
import mvc.dto.BookResponse;
import mvc.dto.Books;
import mvc.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;


@Service
public class BookService {
    @Autowired
    BookRepository bookRepository;
    public BookResponse addBook(Book book){
        System.out.println("At BookService");
        Book b= bookRepository.save(book);
        BookResponse bookResponse= new BookResponse();
        bookResponse.setId(b.getId());
        bookResponse.setIsbn(b.getIsbn());
        bookResponse.setTitle(b.getTitle());
        bookResponse.setAuthor(b.getAuthor());
        bookResponse.setPrice(b.getPrice());
        return bookResponse;
    }
    public BookResponse updateBook(Book book){
        System.out.println("At BookService");
        Book b= bookRepository.save(book);
        BookResponse bookResponse= new BookResponse();
        bookResponse.setIsbn(b.getIsbn());
        bookResponse.setTitle(b.getTitle());
        bookResponse.setAuthor(b.getAuthor());
        bookResponse.setPrice(b.getPrice());
        return bookResponse;
    }

    public BookResponse deleteBook(Integer id){
        System.out.println("At BookService(delete)");
        BookResponse bookResponse= null;

        if(bookRepository.findById(id).isPresent()) {
            Book b = bookRepository.findById(id).get();
            bookRepository.deleteById(id);
            bookResponse=new BookResponse();
            bookResponse.setIsbn(b.getIsbn());
            bookResponse.setTitle(b.getTitle());
            bookResponse.setAuthor(b.getAuthor());
            bookResponse.setPrice(b.getPrice());
        }
        return bookResponse;
    }

    public BookResponse getBook(String isbn){
        System.out.println("At BookService(getBookByISBN)");
        Book b= bookRepository.findByIsbn(isbn);
        BookResponse bookResponse=new BookResponse();
        bookResponse.setIsbn(b.getIsbn());
        bookResponse.setTitle(b.getTitle());
        bookResponse.setAuthor(b.getAuthor());
        bookResponse.setPrice(b.getPrice());
        return bookResponse;
    }

    public Books getAllBooks(String author){
        Books bookList= new Books();
        System.out.println("At BookService(get All Book)");
        if(author !=null){
            List<BookResponse> list=  bookRepository.findByAuthor(author).stream().map(b-> {
                BookResponse bookResponse=new BookResponse();
                bookResponse.setIsbn(b.getIsbn());
                bookResponse.setTitle(b.getTitle());
                bookResponse.setAuthor(b.getAuthor());
                bookResponse.setPrice(b.getPrice());
                return bookResponse;
        }).collect(Collectors.toList());
            bookList.setBookResponses(list);
    }
        else{
            List<BookResponse> list=  bookRepository.findAll().stream().map(b->{
                BookResponse bookResponse=new BookResponse();
                bookResponse.setIsbn(b.getIsbn());
                bookResponse.setTitle(b.getTitle());
                bookResponse.setAuthor(b.getAuthor());
                bookResponse.setPrice(b.getPrice());
                return bookResponse;
            }).collect(Collectors.toList());

            bookList.setBookResponses(list);
        }

        return bookList;
    }

}
