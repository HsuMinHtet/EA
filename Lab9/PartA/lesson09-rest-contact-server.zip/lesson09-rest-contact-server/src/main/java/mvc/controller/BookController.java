package mvc.controller;

import mvc.domain.Book;
import mvc.domain.Contact;
import mvc.dto.BookResponse;
import mvc.dto.Books;
import mvc.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin
public class BookController {
    @Autowired
    BookService bookService;
    private Map<String, Book> books = new HashMap<String, Book>();


    @PostMapping("/books")
    public ResponseEntity<?> addBook(@RequestBody Book book){
      //  books.put(book.getIsbn(), book);
        System.out.println("At BookController ");
        return new ResponseEntity<BookResponse>(bookService.addBook(book), HttpStatus.OK);
    }
    //http://localhost:8080/books/1 from PostMan
    @PutMapping("/books/{isbn}")
    public ResponseEntity<?> updateBook(@PathVariable String isbn, @RequestBody Book book){
        return new ResponseEntity<BookResponse>(bookService.updateBook(book), HttpStatus.OK);
    }

    @DeleteMapping("/books/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable Integer id){
        return new ResponseEntity<BookResponse>(bookService.deleteBook(id), HttpStatus.OK);
    }


    @GetMapping("/books")
    public ResponseEntity<?> getBook(@RequestParam(name = "author",required = false) String author){
        System.out.println("At BookController ");
        Books b=  bookService.getAllBooks(author);
        return new ResponseEntity<Books>(b, HttpStatus.OK);
    }

}
