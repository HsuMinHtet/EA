package mvc.dto;

import lombok.Data;

@Data
public class BookResponse {
    private int id;
    private String isbn;
    private String author;
    private String title;
    private double price;

    public BookResponse() {
    }

    public BookResponse(int id, String isbn, String author, String title, double price) {
        this.id= id;
        this.isbn = isbn;
        this.author = author;
        this.title = title;
        this.price = price;
    }
}
