package mvc.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;

@Data
@Entity
public class Book {
    @Id
    @GeneratedValue
    private int id;
    @Getter
    private String isbn;
    private String author;
    private String title;
    private double price;


    public Book() {
    }

    public Book(String isbn, String author, String title, double price) {
        this.isbn = isbn;
        this.author = author;
        this.title = title;
        this.price = price;
    }

    public int getId() {
        return id;
    }
}
