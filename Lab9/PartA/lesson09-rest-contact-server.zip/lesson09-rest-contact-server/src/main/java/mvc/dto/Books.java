package mvc.dto;

import lombok.Data;
import mvc.domain.Book;

import java.util.Collection;
@Data
public class Books {

    private Collection<BookResponse> bookResponses;
}
