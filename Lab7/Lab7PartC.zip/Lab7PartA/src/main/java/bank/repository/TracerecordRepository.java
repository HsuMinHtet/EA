package bank.repository;


import bank.domain.Customer;
import bank.domain.Tracerecord;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TracerecordRepository extends JpaRepository<Tracerecord, Long> {
    @Transactional(Transactional.TxType.REQUIRES_NEW)
    default void createAccountCustomer(Tracerecord tracerecord) {
        //throw new RuntimeException("could not save customer");
        save(tracerecord);
    }

}




