package bank.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

@Entity
public class Tracerecord {
    @Id
    @GeneratedValue
    private Long id;

    private LocalDateTime dateTime;

    private String result;

    public Tracerecord(LocalDateTime dateTime, String result) {
        this.dateTime = dateTime;
        this.result = result;
    }

    public Tracerecord() {

    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Long getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Tracerecord{" +
                "id=" + id +
                ", dateTime=" + dateTime +
                ", result='" + result + '\'' +
                '}';
    }
}
