package bank.Controller;

import bank.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class BankStatementPrinter {

    @Autowired
    AccountService accountService;

    @Scheduled(fixedRate = 20000)
    public void print(){
        accountService.showBalance();
        System.out.println("This is print");
    }
}
