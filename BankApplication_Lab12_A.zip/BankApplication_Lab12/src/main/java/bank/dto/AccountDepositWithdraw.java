package bank.dto;

import org.apache.kafka.common.errors.SerializationException;

public class AccountDepositWithdraw extends SerializationException {
    private long accountnumber;
    private String currency;
    private double amount;

    public AccountDepositWithdraw(long accountnumber, String currency, double amount) {
        this.accountnumber = accountnumber;
        this.currency = currency;
        this.amount = amount;
    }

    public long getAccountnumber() {
        return accountnumber;
    }

    public void setAccountnumber(long accountnumber) {
        this.accountnumber = accountnumber;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
