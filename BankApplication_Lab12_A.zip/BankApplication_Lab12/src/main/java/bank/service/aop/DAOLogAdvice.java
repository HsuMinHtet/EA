package bank.service.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import bank.integration.logging.Logger;
@Aspect
@Configuration
public class DAOLogAdvice {
	
	@Autowired
	private Logger log;
	
	@Before("execution(* bank.repository.*.*(..))")
	public void logDAOCall(JoinPoint joinpoint) {
		log.log(" method= " + joinpoint.getSignature().getName());
	}

}
