package bank.service;


import bank.dto.AccountCreateDTO;
import bank.dto.AccountDepositWithdraw;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class BankReceiver {
    @Autowired
    AccountService accountService;
//
//    @KafkaListener(topics = {"CreatAccount"})
//    public void receiveCreate(@Payload AccountCreateDTO account) {
//        accountService.createAccount(account.getAccountnumber(),account.getName());
//        System.out.println("Receiver create message= "+ account);
//    }
//    @KafkaListener(topics = {"DepositAccount"})
//    public void receiveDeposit(@Payload  AccountDepositWithdraw account) {
//        if(account.getCurrency().equals("US")){
//            accountService.deposit(account.getAccountnumber(),account.getAmount());
//        }else{
//            accountService.depositEuros(account.getAccountnumber(),account.getAmount());
//        }
//        System.out.println("Receiver deposit message= "+ account);
//    }
//    @KafkaListener(topics = {"WithdrawAccount"})
//    public void receiveWithdraw(@Payload AccountDepositWithdraw account) {
//        if(account.getCurrency().equals("US")){
//            accountService.withdraw(account.getAccountnumber(),account.getAmount());
//        }else{
//            accountService.withdrawEuros(account.getAccountnumber(),account.getAmount());
//        }
//        System.out.println("Receiver Withdraw message= "+ account);
//    }

}