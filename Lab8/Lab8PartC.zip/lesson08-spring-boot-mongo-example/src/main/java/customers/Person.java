package customers;

import java.util.*;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Person {
	private String id;
	
	private String firstname;
	
	private String lastname;
	
	private List<Pet> petList= new ArrayList<>();
	
	
	public Person( String firstname, String lastname, List<Pet> petList) {
		this.firstname = firstname;
		this.lastname = lastname;
		this.petList = petList;
	}



	public Person() {
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<Pet> getPetList() {
		return petList;
	}

	public void setPetList(List<Pet> petList) {
		this.petList = petList;
	}



	public String getFirstname() {
		return firstname;
	}



	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}



	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	@Override
	public String toString() {
		return "Person [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", petList=" + petList
				+ "]";
	}
	
	

}
