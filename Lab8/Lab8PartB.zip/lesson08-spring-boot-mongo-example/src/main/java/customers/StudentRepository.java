package customers;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;

public interface StudentRepository extends MongoRepository<Student, String>{
	
	@Query("{name::#{#name}}")
	List<Student> findStudentWithName(@Param("name")String name);
	
	List<Student> findByPhone(String phone);
	
	@Query("{'addresss.city'::#{#city}}")
	List<Student> findStudentWithCity(String city);
	
	//@Query("{ 'grades': { $elemMatch:  { 'name' : :#{#courseName} } }}")
	@Query("{'grades':{$elemMatch:{'courseName'::#{#courseName}}}}")
	List<Student> findByCourse(String courseName);

	//@Query("{ 'grades': { $elemMatch:  { 'name' : :#{#courseName},'grade':'A+' } }}")
	@Query("{'grades':{$elemMatch:{'courseName'::#{#courseName},'grade':'A+'}}}")
	List<Student> findByCourseWithA(@Param("courseName")String courseName);
	
}

