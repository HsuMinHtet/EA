package customers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Student {
	@Id
	private String studentNumber;
	private String name;
	private String phone;
	private Address addresss;
	private List<Grade> grades=new ArrayList<>();
	public Student( String name, String phone, Address addresss,List<Grade> grades) {
		
		this.name = name;
		this.phone = phone;
		this.addresss = addresss;
		this.grades=grades;
	}

	public Student() {
	}

	public String getStudentNumber() {
		return studentNumber;
	}

	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Address getAddresss() {
		return addresss;
	}

	public void setAddresss(Address addresss) {
		this.addresss = addresss;
	}

	@Override
	public String toString() {
		return "Student [studentNumber=" + studentNumber + ", name=" + name + ", phone=" + phone + ", addresss="
				+ addresss + "]";
	}
	
}
