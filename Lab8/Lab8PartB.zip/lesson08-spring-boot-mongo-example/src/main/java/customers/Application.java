package customers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;


@SpringBootApplication
public class Application implements CommandLineRunner {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private StudentRepository studentRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		studentAddress();

	}
	
	public void customerCreditCard() {
        // create customer
		Customer customer = new Customer(101,"John doe", "johnd@acme.com", "0622341678");
		CreditCard creditCard = new CreditCard("12324564321", "Visa", "11/23");
		customer.setCreditCard(creditCard);
		customerRepository.save(customer);

		customer = new Customer(109,"John Jones", "jones@acme.com", "0624321234");
		creditCard = new CreditCard("657483342", "Visa", "09/23");
		customer.setCreditCard(creditCard);
		customerRepository.save(customer);

		customer = new Customer(66,"James Johnson", "jj123@acme.com", "068633452");
		creditCard = new CreditCard("99876549876", "MasterCard", "01/24");
		customer.setCreditCard(creditCard);
		customerRepository.save(customer);

		//get customers
		System.out.println(customerRepository.findById(66).get());
		System.out.println(customerRepository.findById(101).get());
		System.out.println("-----------All customers ----------------");
		System.out.println(customerRepository.findAll());

		//update customer
		customer = customerRepository.findById(101).get();
		customer.setEmail("jd@gmail.com");
		customerRepository.save(customer);
		System.out.println("-----------find by phone ----------------");
		System.out.println(customerRepository.findByPhone("0622341678"));
		System.out.println("-----------find by email ----------------");
		System.out.println(customerRepository.findCustomerWithEmail("jj123@acme.com"));
		System.out.println("-----------find customers with a certain type of creditcard ----------------");

		List<Customer> customers = customerRepository.findCustomerWithCreditCardType("Visa");

		customers.forEach(System.out::println);
	}
	public void studentAddress() {
		Grade grade1 = new Grade("WAA","B+");
		Grade grade2 = new Grade("EA","A+");
		Grade grade3 = new Grade("WAA","B+");
		List<Grade> grades1= new ArrayList<>();
		grades1.add(grade1);
		grades1.add(grade2);
		grades1.add(grade3);
		Address add1= new Address("1000N","NY", "52557");
		Student stu1 = new Student("Tom","1111111",add1,grades1);
		//studentRepository.save(stu1);
		
		List<Grade> grades2= new ArrayList<>();
		grades2.add(new Grade("WAA","A+"));
		grades2.add(new Grade("EA","A+"));
		Address add2= new Address("1000N","Fairfield", "52557");
		Student stu2 = new Student("Jame","23235323232",add2,grades2);
		//studentRepository.save(stu2);
		
		List<Grade> grades3= new ArrayList<>();
		grades3.add(new Grade("WAA","A+"));
		grades3.add(new Grade("EA","A+"));
		Address add3= new Address("1000N","LA", "52557");
		Student stu3 = new Student("Mill","2323535",add3,grades3);
		//studentRepository.save(stu3);
		
		//studentRepository.findStudentWithName("Tom").forEach(System.out::println);
		
		
		//studentRepository.findByPhone("1111111").forEach(System.out::println);
		
		
		//studentRepository.findStudentWithCity("NY").forEach(System.out::println);
		
		System.out.print("For Course");
		
		studentRepository.findByCourse("EA").forEach(System.out::println);
		
		studentRepository.findByCourseWithA("WAA").forEach(System.out::println);
	}

}
