package repositories;

import domain.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AddressRepository extends JpaRepository<Address,Long> {
    @Query(value="SELECT * from Address WHERE city=:city",nativeQuery = true)
    List<Address> getAddressByCity(String city);

}
