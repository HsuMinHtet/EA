package repositories;

import domain.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer,Long> {
     List<Customer> findAll();
     List<Customer> findByCountry(@Param("countryName") String country);
     @Query("select concat(c.firstName,' ',c.lastName) from Customer c where c.address.city=:city")
     List<String> getAllCustomerNameLiveInAmsterdam(String city);
}
