package repositories;

import domain.CD;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CDRepository extends JpaRepository<CD,Long> {
    List<CD> findAllByArtist(String a);
    List<CD> CDByArtist(String artist);
    @Query("select c from CD c where c.artist=:artist and c.price > :price")
    List<CD> getAllCDByArtistAndPrice(String artist, double price);
    @Query(value = "select * from CD WHERE artist=:artist",nativeQuery = true)
    List<CD> getAllCDByArtist(String artist);

}
