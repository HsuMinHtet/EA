package app;

import domain.*;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import repositories.*;

@SpringBootApplication
@EnableJpaRepositories("repositories")
@EntityScan("domain") 
public class Application implements CommandLineRunner{
	
	@Autowired
	AddressRepository addressRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	OrderLineRepository orderLineRepository;
	@Autowired
	ProductRepository productRepository;
	@Autowired
	CDRepository cdRepository;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	@Transactional
	@Override
	public void run(String... args) throws Exception {

		Product product = new Product();
		product.setName("Hibernate 3");
		product.setDescription("Good book on Hibernate");
		product.setPrice(35.50);
		productRepository.save(product);
		OrderLine ol1 = new OrderLine(2, product);
		orderLineRepository.save(ol1);

		Product product2 = new Product();
		product2.setName("The best of Queen");
		product2.setDescription("Album from 1995");
		product2.setPrice(12.98);
		productRepository.save(product2);
		OrderLine ol2 = new OrderLine(4, product2);
		orderLineRepository.save(ol2);

		Order o1 = new Order("234743", "12/10/06", "open");
		Order o2 = new Order("222xxx", "12/10/08", "closed");
		o1.addOrderLine(ol1);
		o1.addOrderLine(ol2);

		Customer c1 = new Customer("Frank", "Brown", "Mainstreet 1",
				"Amsterdam", "43221","USA");
		c1.addOrder(o1);
		addressRepository.save(c1.getAddress());
		customerRepository.save(c1);

		Customer c2 = new Customer("Flappy", "Brown", "Mainstreet 1",
				"Amsterdam", "43221","USA");
		c2.addOrder(o1);
		addressRepository.save(c2.getAddress());
		customerRepository.save(c2);

		o1.setCustomer(c1);
		orderRepository.save(o1);
		orderRepository.save(o2);

		//printOrder(o1);
		//lab5Prod();
		lab6Prod();

	}
	public static void printOrder(Order order) {
		System.out.println("Order with orderNumber: " + order.getOrderNumber());
		System.out.println("Order date: " + order.getDate());
		System.out.println("Order status: " + order.getStatus());
		Customer cust = order.getCustomer();
		System.out.println("Customer: " + cust.getFirstName() + " "
				+ cust.getLastName());
		for (OrderLine orderline : order.getOrderLines()) {
			System.out.println("Order line: quantity= "
					+ orderline.getQuantity());
			Product product = orderline.getProduct();
			System.out.println("Product: " + product.getName() + " "
					+ product.getDescription() + " " + product.getPrice());
		}
	}
	public  void lab5Prod(){
		Product cd = new CD("CD1","U2",9,"Tommy");
		Product cd2 = new CD("CD1","U2",11,"Gimmy");

		Product dvd= new DVD("DVD1","This is DVD", 200.11, "Tim");

		Product book= new Book("Book1","This is book",100.02,"2334ISBN");

		productRepository.save(cd);
		productRepository.save(cd2);
		productRepository.save(dvd);
		productRepository.save(book);

		productRepository.findAll().stream().map((prd)->{
			if(prd instanceof DVD)
				return ((DVD)prd).toString();
			if(prd instanceof CD)
				return ((CD)prd).toString();
			if(prd instanceof Book)
				return ((Book)prd).toString();
			return prd.toString();
		}).forEach(System.out::println);
	}

	public void lab6Prod(){
		productRepository.save(new CD("CD1","Tommy",19,"U2"));
		productRepository.save(new CD("CD1","Gimmy",11,"U2"));
		System.out.println(".......Lab6........");
		cdRepository.findAll().forEach(System.out::println);
		cdRepository.findAllByArtist("U2").forEach(System.out::println);
		customerRepository.findAll().forEach(System.out::println);

		customerRepository.findByCountry("USA").forEach(System.out::println);
		cdRepository.CDByArtist("U2").forEach(System.out::println);

		orderRepository.findAllByStatus("closed").forEach(System.out::println);
		customerRepository.getAllCustomerNameLiveInAmsterdam("Amsterdam").forEach(System.out::println);

		System.out.println("Order List");
		orderRepository.getOrderListByCity("Amsterdam").forEach(System.out::println);

		System.out.println("All CD");
		cdRepository.getAllCDByArtistAndPrice("U2",5).forEach(System.out::println);

		System.out.println("Native All Address");
		addressRepository.getAddressByCity("Amsterdam").forEach(System.out::println);

		System.out.println("Native All CD");
		cdRepository.CDByArtist("U2").forEach(System.out::println);

	}

}
