package repository;

import domain.Book;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {
    @Modifying
    @Transactional
    @Query("update Book b set b.locationCode = concat('BB',b.locationCode)")
    void updateBookLocation();
    @Modifying
    @Transactional
    @Query("delete from Book b where b.publicationYear < :publicationYear")
    void removeAllBookByPublicationYear(int publicationYear);

}
