package domain;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Student {

    @Id
    @GeneratedValue
    private Long studentNumber;

    private String name;

    @OneToOne(cascade = {CascadeType.PERSIST})
    private Department department;
    @OneToMany(cascade ={CascadeType.PERSIST})
    private List<Grade> gradeList;

    public Student(String name, Department department, List<Grade> gradeList) {
        this.name = name;
        this.department = department;
        this.gradeList = gradeList;
    }

    public List<Grade> getGradeList() {
        return gradeList;
    }

    public void setGradeList(List<Grade> gradeList) {
        this.gradeList = gradeList;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Student() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getId() {
        return studentNumber;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentNumber=" + studentNumber +
                ", name='" + name + '\'' +
                ", department=" + department +
                ", gradeList=" + gradeList +
                '}';
    }
}
