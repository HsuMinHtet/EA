package Lab6PartB;

import domain.Course;
import domain.Department;
import domain.Grade;
import domain.Student;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import repositories.CourseRepository;
import repositories.DepartmentRepository;
import repositories.StudentRepository;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
@EnableJpaRepositories("repositories")
@EntityScan("domain")
public class Lab6PartBApplication implements CommandLineRunner {
	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private CourseRepository courseRepository;
	@Autowired
	private DepartmentRepository departmentRepository;

	public static void main(String[] args) {
		SpringApplication.run(Lab6PartBApplication.class, args);
	}
	@Transactional
	@Override
	public void run(String... args) throws Exception {
		lab6PartB();
	}

	public void lab6PartB(){
		Department department= new Department("CS_Dep");

		Course course= new Course("Java");
		Course course1= new Course("WAA");
		List<Grade> gradeList1= new ArrayList<>();
		gradeList1.add(new Grade("A+",course));
		gradeList1.add(new Grade("A",course1));
		Student student= new Student("Tom",department,gradeList1);

		studentRepository.save(student);

		 course= new Course("EA");
		 course1= new Course("WAA");
		List<Grade> gradeList2 = new ArrayList<>();
		gradeList2.add(new Grade("B",course));
		gradeList2.add(new Grade("A",course1));
		Student student2= new Student("Honey",department,gradeList2);

		//studentRepository.save(student2);

		studentRepository.findAllStudentByDepName("CS_Dep").forEach(System.out::println);
		studentRepository.findAllStudentByCourse("Java").forEach(System.out::println);
	}
}
