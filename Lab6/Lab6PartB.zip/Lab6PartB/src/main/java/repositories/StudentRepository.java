package repositories;

import domain.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface StudentRepository extends JpaRepository<Student,Long> {

    @Query("select stu from Student  stu where stu.department.name=:name")
    List<Student> findAllStudentByDepName(String name);
    @Query("select stu from Student  stu join stu.gradeList grd where grd.course.name=:course")
    List<Student> findAllStudentByCourse(String course);
}
