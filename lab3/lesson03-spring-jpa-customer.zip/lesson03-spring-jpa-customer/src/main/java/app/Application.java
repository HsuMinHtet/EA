package app;

import domain.Book;
import domain.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import repository.BookRepository;
import repository.CustomerRepository;

import java.util.Optional;

@SpringBootApplication
@EnableJpaRepositories("repository")
@EntityScan("domain") 
public class Application implements CommandLineRunner{
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	BookRepository bookRepository;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		customerRepository.save(new Customer("Jack", "Bauer", "jack@acme.com"));
		customerRepository.save(new Customer("Chloe", "O'Brian", "chloe@acme.com"));
		customerRepository.save(new Customer("Kim", "Bauer", "kim@acme.com"));
		customerRepository.save(new Customer("David", "Palmer", "dpalmer@gmail.com"));
		customerRepository.save(new Customer("Michelle", "Dessler", "mich@hotmail.com"));

		// fetch all customers
		System.out.println("Customers found with findAll():");
		System.out.println("-------------------------------");
		for (Customer customer : customerRepository.findAll()) {
			System.out.println(customer);
		}
		System.out.println();

		// fetch an individual customer by ID
		Optional<Customer> custOpt = customerRepository.findById(1L);
		Customer customer = custOpt.get();
		System.out.println("Customer found with findOne(1L):");
		System.out.println("--------------------------------");
		System.out.println(customer);
		System.out.println();

		bookRepository.save(new Book( "Spring Awaking", "00293434", "Dr.Wake", 300.34));
		bookRepository.save(new Book( "AWS", "00293434", "Dr.Tina", 500.30));
		bookRepository.save(new Book( "EA", "00293434", "Dr.Payment", 600.50));
		
		// fetch all customers
		System.out.println("Book found with findAll():");
		System.out.println("-------------------------------");
		bookRepository.findAll().forEach(System.out::println);
		
		//update
		Optional<Book>  b3= bookRepository.findByAuthor("Dr.Tina");
		b3.get().setAuthor("Dr. Author3");
		bookRepository.save(b3.get());
		
		//delete
		Optional<Book> b2 = bookRepository.findById(2);
		bookRepository.delete(b2.get());
		
		
		bookRepository.findAll().forEach(System.out::println);
		
		
		
	}

}
