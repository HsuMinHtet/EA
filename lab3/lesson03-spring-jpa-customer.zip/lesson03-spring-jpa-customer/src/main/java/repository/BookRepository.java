package repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import domain.Book;

public interface BookRepository extends JpaRepository<Book, Integer> {

    Optional<Book> findByAuthor(String author);

//    Customer findByFirstNameAndLastName(String fistName, String lastName);
//
//    List<Customer> findFirst2By(); 
//    
//    @Query("select c.lastName from Customer c where c.firstName= :firstName")
//    String findLastNameByFirstName(@Param("firstName") String firstName);
}
