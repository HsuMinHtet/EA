package domain;

import jakarta.persistence.*;

import java.nio.channels.FileLock;
import java.text.FieldPosition;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Passenger {
    @Id
    @GeneratedValue
    @Column(name="Id")
    private long id;
    @Column(name="Name")
    private String name;
    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(name="Passenger_Flight")
    @OrderColumn(name="sequence")
    private List<Flight> flightList=new ArrayList<Flight>();
    public Passenger(String name, List<Flight> flightList) {
        this.name = name;
        this.flightList = flightList;
    }

    public Passenger() {

    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Flight> getFlightList() {
        return flightList;
    }

    public void setFlightList(List<Flight> flightList) {
        this.flightList = flightList;
    }

    @Override
    public String toString() {
        return "Passenger{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", flightList=" + flightList.toString() +
                '}';
    }
}
