package domain;

import jakarta.persistence.*;

import java.util.HashMap;
import java.util.Map;

@Entity
public class School {
    @Id
    @GeneratedValue
    @Column(name="Id")
    private long id;
    @Column(name="Name")
    private String name;
    @OneToMany(fetch = FetchType.EAGER)
    @MapKey(name="studentid")
    private Map<Long,Student> studentList = new HashMap<Long,Student>();

    public School(String name, Map<Long, Student> studentList) {
        this.name = name;
        this.studentList = studentList;
    }

    public School() {

    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<Long, Student> getStudentList() {
        return studentList;
    }

    public void setStudentList(Map<Long, Student> studentList) {
        this.studentList = studentList;
    }

    @Override
    public String toString() {
        return "School{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", studentList=" + studentList.toString() +
                '}';
    }
}
