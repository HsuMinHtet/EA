package domain;

import jakarta.persistence.*;

import java.util.List;
import java.util.ArrayList;

@Entity
public class Department {
    @Id
    @GeneratedValue
    @Column(name = "Id")
    private int id;
    @Column(name ="Name")
    private String name;

    @OneToMany(mappedBy = "department",fetch = FetchType.EAGER)
    private List<Employee> employeeList= new ArrayList<>();

    public Department( String name) {
        this.name = name;
    }

    public List<Employee> getEmployeeList() {
        return employeeList;
    }

    public void setEmployeeList(List<Employee> employeeList) {
        this.employeeList = employeeList;
    }

    public Department() {

    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Department{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", employeeList=" + employeeList.toString() +
                '}';
    }
}
