package domain;

import jakarta.persistence.*;

import java.util.*;

@Entity
public class Employee {

    @Id
    @GeneratedValue
    @Column(name = "EmployeeNumber")
    private long employeenumber;

    @Column(name ="name")
    private String name;

    @ManyToOne
    @JoinTable(name="Employee_Department")
    private Department department;

    public Employee(String name, Department department) {
        this.name = name;
        this.department=department;
    }

    public Employee() {

    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public long getEmployeenumber() {
        return employeenumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeenumber=" + employeenumber +
                ", name='" + name + '\'' +
                '}';
    }
}
