package domain;

import jakarta.persistence.*;

@Entity
public class Book {
    @Id
    @GeneratedValue
    @Column(name="Id")
    private long id;
    @Column(name="ISBN")
    private long isbn;
    @Column(name="Title")
    private String title;
    @Column(name="Author")
    private String author;

    @ManyToOne
    @JoinTable(name="Book_Publisher",
            joinColumns = {@JoinColumn(name="BookId")},
            inverseJoinColumns = {@JoinColumn(name="PublisherId")}
    )
    private Publisher publisher;

    public Book(long isbn, String title, String author, Publisher publisher) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
    }

    public Book() {

    }

    public long getId() {
        return id;
    }

    public long getIsbn() {
        return isbn;
    }

    public void setIsbn(long isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Publisher getPublisher() {
        return publisher;
    }

    public void setPublisher(Publisher publisher) {
        this.publisher = publisher;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", isbn=" + isbn +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", publisher=" + publisher +
                '}';
    }
}
