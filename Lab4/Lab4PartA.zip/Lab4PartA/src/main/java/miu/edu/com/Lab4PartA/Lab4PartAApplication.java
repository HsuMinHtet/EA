package miu.edu.com.Lab4PartA;

import domain.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import repository.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

@SpringBootApplication
@EnableJpaRepositories("repository")
@EntityScan("domain")
public class Lab4PartAApplication implements CommandLineRunner {

	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	DepartmentRepository departmentRepository;
	@Autowired
	PublisherRepository publisherRepository;
	@Autowired
	BookRepository bookRepository;
	@Autowired
	PassengerRepository passengerRepository;
	@Autowired
	FlightRepository flightRepository;
	@Autowired
	StudentRepository studentRepository;
	@Autowired
	SchoolRepository schoolRepository;

	public static void main(String[] args) {
		SpringApplication.run(Lab4PartAApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		employeeDepartmentMethod();
		System.out.println("------------------------------------");
		bookPublisher();
		System.out.println("------------------------------------");
		passengerFlight();
		System.out.println("------------------------------------");
		schoolStudent();
		System.out.println("------------------------------------");
	}

	public void employeeDepartmentMethod(){
		Department department= new Department("CS_Dep");
		Employee e1 = new Employee("Aung",department);
		Employee e2 = new Employee("Tom",department);
		Employee e3 = new Employee("Hsu",department);

		Department department1= new Department("MBA_Dep");
		Employee e4 = new Employee("Jame",department1);
		Employee e5 = new Employee("Will",department1);
		Department department2= new Department("Admin_Dep");
		Employee e6 = new Employee("Amy",department2);

		List<Employee> employeeList= new ArrayList<Employee>();
		employeeList.add(e1);
		employeeList.add(e2);
		employeeList.add(e3);
		department.setEmployeeList(employeeList);

		List<Employee> employeeList1= new ArrayList<Employee>();
		employeeList1.add(e4);
		employeeList1.add(e5);
		department1.setEmployeeList(employeeList1);

		List<Employee> employeeList2= new ArrayList<Employee>();
		employeeList2.add(e6);
		department2.setEmployeeList(employeeList2);

		departmentRepository.save(department);
		departmentRepository.save(department1);
		departmentRepository.save(department2);
		employeeRepository.save(e1);
		employeeRepository.save(e2);
		employeeRepository.save(e3);
		employeeRepository.save(e4);
		employeeRepository.save(e5);
		employeeRepository.save(e6);

		//departmentRepository.findAll().forEach(System.out::println);
		departmentRepository.flush();
		departmentRepository.findAll().forEach(System.out::println);
	}

	public void bookPublisher(){

		Publisher publisher= new Publisher("Pub1");
		Book book1 = new Book(223L,"Book1","Author1",publisher);

		publisherRepository.save(publisher);
		bookRepository.save(book1);
		bookRepository.findAll().forEach(System.out::println);

	}

	public void passengerFlight(){
		Flight f1= new Flight("001A","Yangon","USA", LocalDate.now());
		Flight f2= new Flight("002A","Thai","USA", LocalDate.now());
		Flight f3= new Flight("003V","Chicago","USA", LocalDate.now());
		List<Flight> flightList= new ArrayList<>();
		flightList.add(f1);
		flightList.add(f2);
		flightList.add(f3);

		Passenger passenger= new Passenger("Tommy",flightList);

		flightRepository.save(f1);
		flightRepository.save(f2);
		flightRepository.save(f3);
		passengerRepository.save(passenger);
		passengerRepository.findAll().forEach(System.out::println);

	}

	public void schoolStudent(){
		Student stu1= new Student("Tommy","Jame");
		Student stu2= new Student("Flippy","Jame");
		Student stu3= new Student("Gome","Tim");

		studentRepository.save(stu1);
		studentRepository.save(stu2);
		studentRepository.save(stu3);

		Map<Long,Student> studentMap= new HashMap<>();
		studentMap.put(stu1.getStudentid(),stu1);
		studentMap.put(stu2.getStudentid(),stu2);
		studentMap.put(stu3.getStudentid(),stu3);

		School school= new School("MIU", studentMap);
		schoolRepository.save(school);

		schoolRepository.findAll().forEach(System.out::println);
	}

}
