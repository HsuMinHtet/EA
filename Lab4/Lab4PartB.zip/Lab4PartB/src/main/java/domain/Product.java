package domain;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
@Entity
public class Product {
	@Id
	@GeneratedValue
	@Column(name="Id")
	private long productNumber;
	@Column(name="Name")
	private String name;
	@Column(name="Description")
	private String description;
	@Column(name="Price")
	private double price;

	public long getProductNumber() {
		return productNumber;
	}

	public Product() {
	}

	public Product(String name, String description, double price) {
		this.name = name;
		this.description = description;
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
