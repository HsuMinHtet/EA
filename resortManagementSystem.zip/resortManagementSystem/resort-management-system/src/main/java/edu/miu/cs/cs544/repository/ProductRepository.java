package edu.miu.cs.cs544.repository;

import edu.miu.cs.cs544.domain.Address;
import edu.miu.cs.cs544.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    // Method query to get the maxCapacity by ID
    @Query("SELECT p.maxCapacity FROM Product p WHERE p.id = :productId")
    Integer findMaxCapacityById(@Param("productId") Long productId);
}