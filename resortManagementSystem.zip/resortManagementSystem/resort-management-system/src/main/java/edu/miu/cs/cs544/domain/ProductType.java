package edu.miu.cs.cs544.domain;

public enum ProductType {
	Room, Villa, Apartment, Tent
}
