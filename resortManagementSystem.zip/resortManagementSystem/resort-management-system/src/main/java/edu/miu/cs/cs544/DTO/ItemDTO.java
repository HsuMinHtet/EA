package edu.miu.cs.cs544.DTO;

import edu.miu.cs.cs544.domain.AuditData;
import lombok.Data;

import java.time.LocalDate;
@Data
public class ItemDTO {

    private Long id;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private int numberOfOccupants;
    private AuditData auditData;
    private ProductDTO productDTO;

}