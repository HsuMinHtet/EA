package edu.miu.cs.cs544.service;

import edu.miu.cs.cs544.DTO.UserDTO;
import edu.miu.cs.cs544.domain.*;
import edu.miu.cs.cs544.repository.UserRepository;
import edu.miu.cs.cs544.util.AuditDataCreate;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserService implements UserDetailsService {
    @Autowired
    UserRepository userRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private PasswordEncoder encoder;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Optional<User> userDetail = userRepository.findByUserName(username);

        // Converting userDetail to UserDetails
        return userDetail.map(UserInfoDetails::new)
                .orElseThrow(() -> new UsernameNotFoundException("User not found " + username));
    }


    public UserDTO getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        return convertToDTO(user);
    }

    public List<UserDTO> getAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream()
                .map(user -> modelMapper.map(user, UserDTO.class))
                .collect(Collectors.toList());
    }

    public UserDTO createUser(UserDTO requestDTO) {
        User user = new User();
        user.setUserName(requestDTO.getUserName());
        user.setUserPass(encoder.encode(requestDTO.getUserPass()));
        user.setActive(true);
        user.setType(UserType.CLIENT);
        AuditData auditData = AuditDataCreate.populateAuditData(requestDTO.getUserName());
        user.setAuditData(auditData);
        // Perform validations or additional logic before saving
        User savedUser = userRepository.save(user);
        return convertToDTO(savedUser);
    }

    public UserDTO updateUser(Long id, UserDTO requestDTO) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User existingUser = optionalUser.get();

            // Update existing user fields
            existingUser.setUserName(requestDTO.getUserName());
            existingUser.setUserPass(requestDTO.getUserPass());
            AuditData auditData = AuditDataCreate.populateAuditData(requestDTO.getUserName());
            existingUser.setAuditData(auditData);

            // Save the updated user
            User updatedUser = userRepository.save(existingUser);
            return modelMapper.map(updatedUser, UserDTO.class);
        } else {
            // Handle the case when the user with the provided ID is not found
            return null;
        }
    }

    public boolean deleteUser(Long id) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User userToDelete = optionalUser.get();
            userRepository.delete(userToDelete);
            return true;
        } else {
            // Handle the case when the user with the provided ID is not found
            return false;
        }
    }

    private UserDTO convertToDTO(User user) {
        return modelMapper.map(user, UserDTO.class);
    }

    private User convertToEntity(UserDTO userDTO) {
        return modelMapper.map(userDTO, User.class);
    }
}
