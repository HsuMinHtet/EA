package edu.miu.cs.cs544.repository;

import edu.miu.cs.cs544.domain.Item;
import edu.miu.cs.cs544.domain.Reservation;
import edu.miu.cs.cs544.domain.ReservationStatus;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    // Retrieve all reservations with flag set to true
    @Query("SELECT r FROM Reservation r WHERE r.flag=true")
    List<Reservation> findAllReservation();

    // Retrieve a reservation by ID with flag set to true
    @Query("SELECT r FROM Reservation r WHERE r.flag=true AND r.id = :id")
    Reservation findReservationById(@Param("id") Long id);

    // Set flag to false for a reservation by ID
    @Modifying
    @Transactional
    @Query("UPDATE Reservation r SET r.flag=false WHERE r.id=:id")
    void updateDeleteFlagById(@Param("id") Long id);

    // Update reservation status to CANCELLED
    @Modifying
    @Transactional
    @Query("UPDATE Reservation r SET r.status='CANCELLED' WHERE r.id=:id AND r.flag=true")
    void updateStatusCancelled(@Param("id") Long id);

    // Update reservation status to PROCESSED
    @Modifying
    @Transactional
    @Query("UPDATE Reservation r SET r.status='PROCESSED' WHERE r.id=:id AND r.flag=true")
    void updateStatusProcessed(@Param("id") Long id);

    // Update reservation status to ARRIVED
    @Modifying
    @Transactional
    @Query("UPDATE Reservation r SET r.status='ARRIVED' WHERE r.id=:id AND r.flag=true")
    void updateStatusArrived(@Param("id") Long id);

    // Update reservation status to DEPARTED
    @Modifying
    @Transactional
    @Query("UPDATE Reservation r SET r.status='DEPARTED' WHERE r.id=:id AND r.flag=true")
    void updateStatusDeparted(@Param("id") Long id);

    // Retrieve items by product ID for a reservation with flag set to true
    @Query("SELECT ri FROM Reservation r JOIN r.items ri WHERE ri.product.id = :product_id AND r.flag= true ")
    List<Item> findItemsByProductId(@Param("product_id") Long product_id);

    // Retrieve items by product ID for a reservation with flag set to true and excluding a specific reservation ID
    @Query("SELECT ri FROM Reservation r JOIN r.items ri WHERE ri.product.id = :product_id AND r.flag= true AND r.id!=:id")
    List<Item> findItemsByProductIdNoReservationId(@Param("product_id") Long product_id, @Param("id") Long id);

    // Retrieve items by reservation ID with flag set to true
    @Query("SELECT r.items FROM Reservation r WHERE r.flag= true AND r.id=:id")
    List<Item> findItemsById(@Param("id") Long id);

    // Update reservation status and total amount
    @Modifying
    @Transactional
    @Query("UPDATE Reservation r SET r.status = :status, r.totalAmount = :totalAmount WHERE r.id = :id")
    void updateReservationStatusAndTotalAmount(
            @Param("id") Long id,
            @Param("status") ReservationStatus status,
            @Param("totalAmount") double totalAmount
    );
}
