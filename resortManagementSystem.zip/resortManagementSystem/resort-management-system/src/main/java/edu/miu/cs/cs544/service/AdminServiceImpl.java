package edu.miu.cs.cs544.service;

import edu.miu.cs.cs544.DTO.AdminDTO;
import edu.miu.cs.cs544.domain.Admin;
import edu.miu.cs.cs544.domain.AuditData;
import edu.miu.cs.cs544.domain.UserType;
import edu.miu.cs.cs544.repository.AdminRepository;
import edu.miu.cs.cs544.repository.UserRepository;
import edu.miu.cs.cs544.util.AuditDataCreate;
import edu.miu.cs.cs544.util.AuditDataUpdate;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PasswordEncoder encoder;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private UserRepository userRepository;

    @Override
    public AdminDTO getAdminById(Long id) {
        Optional<Admin> adminOptional = adminRepository.findById(id);

        if (adminOptional.isPresent()) {
            Admin admin = adminOptional.get();
            return convertToDTO(admin);
        } else {
            // Return null or throw a custom exception indicating admin not found
            throw new EntityNotFoundException("Admin not found for id: " + id);
            // Or handle the situation by returning null or an appropriate DTO
            // return null; // Or return new AdminDTO() or any other appropriate handling
        }
    }

    @Override
    public AdminDTO createAdmin(AdminDTO requestDTO) {
        if(userRepository.findByUserName(requestDTO.getUser().getUserName()).isPresent()){
            throw new IllegalArgumentException("User with this username already exists.");
        }
        Admin admin = new Admin();
        admin.setFirstName(requestDTO.getFirstName());
        admin.setLastName(requestDTO.getLastName());
        admin.setEmail(requestDTO.getEmail());
        AuditData auditData = AuditDataCreate.populateAuditData(requestDTO.getFirstName());
        requestDTO.getUser().setType(UserType.ADMIN);
        requestDTO.getUser().setActive(true);
        requestDTO.getUser().setUserPass(encoder.encode(requestDTO.getUser().getUserPass()));
        requestDTO.getUser().setAuditData(auditData);
        admin.setUser(requestDTO.getUser());
        admin.setAuditData(auditData);

        Admin savedAdmin = adminRepository.save(admin);
        return convertToDTO(savedAdmin);
    }

    @Override
    public AdminDTO updateCustomer(Long id, AdminDTO requestDTO) {
        Optional<Admin> optionalAdmin = adminRepository.findById(id);
        if (optionalAdmin.isPresent()) {
            Admin admin = optionalAdmin.get();
            admin.setFirstName(requestDTO.getFirstName());
            admin.setLastName(requestDTO.getLastName());
            admin.setEmail(requestDTO.getEmail());
            AuditData auditData = AuditDataUpdate.populateAuditData(requestDTO.getFirstName());
            requestDTO.getUser().setAuditData(auditData);
            requestDTO.getUser().setUserPass(encoder.encode(requestDTO.getUser().getUserPass()));
            admin.setUser(requestDTO.getUser());
            admin.setAuditData(auditData);

            // Save the updated customer entity
            Admin updatedAdmin = adminRepository.save(admin);
            return convertToDTO(updatedAdmin);
        } else {
            // Handle the case where the customer with given ID is not found
            return null; // Or throw an exception
        }
    }

    @Override
    public AdminDTO updateAdmin(Long id, AdminDTO adminDTO) {
        Optional<Admin> optionalAdmin = adminRepository.findById(id);
        if (optionalAdmin.isPresent()) {
            Admin existingAdmin = optionalAdmin.get();

            // Update existing admin fields
            existingAdmin.setFirstName(adminDTO.getFirstName());
            existingAdmin.setLastName(adminDTO.getLastName());
            existingAdmin.setEmail(adminDTO.getEmail());
            // Update other fields as needed

            // Save the updated admin
            Admin updatedAdmin = adminRepository.save(existingAdmin);
            return modelMapper.map(updatedAdmin, AdminDTO.class);
        } else {
            // Handle the case when the admin with the provided ID is not found
            return null;
        }
    }

    @Override
    public boolean deleteAdmin(Long id) {
        Optional<Admin> optionalAdmin = adminRepository.findById(id);
        if (optionalAdmin.isPresent()) {
            Admin adminToDelete = optionalAdmin.get();
            adminRepository.delete(adminToDelete);
            return true;
        } else {
            // Handle the case when the admin with the provided ID is not found
            return false;
        }
    }

    private AdminDTO convertToDTO(Admin admin) {
        return modelMapper.map(admin, AdminDTO.class);
    }

    private Admin convertToEntity(AdminDTO adminDTO) {
        return modelMapper.map(adminDTO, Admin.class);
    }
}
