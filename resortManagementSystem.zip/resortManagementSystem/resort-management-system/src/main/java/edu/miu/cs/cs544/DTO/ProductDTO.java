package edu.miu.cs.cs544.DTO;

import edu.miu.cs.cs544.domain.AuditData;
import edu.miu.cs.cs544.domain.ProductType;
import jakarta.persistence.Embedded;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

@Data
public class ProductDTO {

    private Long id;
    private String name;
    private String description;
    private String excerpt;
    private double nightlyRate;
    private int maxCapacity;
    @Enumerated(EnumType.STRING)
    private ProductType type;
    private AuditData auditData;

}