package edu.miu.cs.cs544.domain;

public enum ReservationStatus {
    NEW, PLACED, PROCESSED, ARRIVED, DEPARTED, CANCELLED
}
