package edu.miu.cs.cs544.service;

import edu.miu.cs.cs544.DTO.ItemDTO;

import java.util.List;

public interface ItemService {
    public ItemDTO getItemById(Long id);
    public List<ItemDTO> getAllItemsByReservationId(Long reservationId) ;
    public ItemDTO getItemDetails(Long reservationId, Long itemId) ;

    public ItemDTO createItem(Long reservationId, ItemDTO itemDTO);
    public ItemDTO updateItem(Long reservationId, Long itemId, ItemDTO updatedItemDTO);

    public boolean deleteItem(Long reservationId, Long itemId) ;

}