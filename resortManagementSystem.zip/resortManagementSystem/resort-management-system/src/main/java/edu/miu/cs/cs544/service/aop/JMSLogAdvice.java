package edu.miu.cs.cs544.service.aop;

import edu.miu.cs.cs544.logging.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

@Aspect
@Configuration
public class JMSLogAdvice {
	
	@Autowired
	private Logger logger;
	
	@Before("execution(* edu.miu.cs.cs544.service.ReservationServiceImpl.*(..))")
	public void logJMSMessage(JoinPoint joinpoint) {
		logger.info(" method= " + joinpoint.getSignature().getName()+" Text : ");
	}


}
