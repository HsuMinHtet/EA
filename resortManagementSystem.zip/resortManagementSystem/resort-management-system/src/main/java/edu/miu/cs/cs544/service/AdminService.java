package edu.miu.cs.cs544.service;

import edu.miu.cs.cs544.DTO.AdminDTO;

public interface AdminService {

    AdminDTO getAdminById(Long id);

    AdminDTO createAdmin(AdminDTO requestDTO);

    AdminDTO updateCustomer(Long id, AdminDTO requestDTO);

    AdminDTO updateAdmin(Long id, AdminDTO adminDTO);

    boolean deleteAdmin(Long id);
}