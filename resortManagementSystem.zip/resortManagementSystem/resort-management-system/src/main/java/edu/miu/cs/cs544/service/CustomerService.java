package edu.miu.cs.cs544.service;

import edu.miu.cs.cs544.DTO.CustomerDTO;
import edu.miu.cs.cs544.domain.Customer;

import java.util.List;

public interface CustomerService {

    CustomerDTO getCustomerById(Long id);

    List<CustomerDTO> getAllCustomers();

    CustomerDTO createCustomer(CustomerDTO requestDTO);

    CustomerDTO updateCustomer(Long id, CustomerDTO requestDTO);

    boolean deleteCustomer(Long id);

    CustomerDTO convertToDTO(Customer customer);

    Customer convertToEntity(CustomerDTO customerDTO);
}