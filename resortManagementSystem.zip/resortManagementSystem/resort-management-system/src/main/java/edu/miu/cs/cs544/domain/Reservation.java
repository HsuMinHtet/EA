package edu.miu.cs.cs544.domain;

import java.util.List;

import jakarta.persistence.*;
import lombok.Data;
@Entity
@Table(name = "reservations")
@Data
public class Reservation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "customer_id")
	private Customer customer;

	@OneToMany(mappedBy = "reservation",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Item> items;

	@Embedded
	private AuditData auditData;

	@Enumerated(EnumType.STRING)
	private ReservationStatus status;

	private boolean flag;

	private double totalAmount;

}
