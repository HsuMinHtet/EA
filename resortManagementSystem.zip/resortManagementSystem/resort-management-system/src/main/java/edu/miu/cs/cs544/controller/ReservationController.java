package edu.miu.cs.cs544.controller;

import edu.miu.cs.cs544.DTO.*;
import edu.miu.cs.cs544.service.ItemService;
import edu.miu.cs.cs544.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/{customerId}/reservations")
public class ReservationController {

    private final ReservationService reservationService;

    @Autowired
    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<ReservationDTO>> getAllReservations() {
        List<ReservationDTO> reservations = reservationService.getAllReservations();
        return ResponseEntity.ok().body(reservations);
    }

    @GetMapping("/{reservationId}")
    @PreAuthorize("hasAuthority('CLIENT')")
    public ResponseEntity<ReservationDetailDTO> getReservationById(@PathVariable Long reservationId) {
        ReservationDetailDTO reservation = reservationService.getReservationById(reservationId);
        return reservation != null ?
                ResponseEntity.ok().body(reservation) :
                ResponseEntity.notFound().build();
    }

    @PostMapping
    @PreAuthorize("hasAuthority('CLIENT')")
    public ResponseEntity<ReservationDTO> makeReservation(@PathVariable Long customerId, @RequestBody ReservationRequestDTO reservationRequest) {
        ReservationDTO createdReservation = reservationService.createReservation(customerId, reservationRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdReservation);
    }

    @PutMapping("/{reservationId}")
    @PreAuthorize("hasAuthority('CLIENT')")
    public ResponseEntity<ReservationDTO> updateReservation(@PathVariable Long customerId, @PathVariable Long reservationId, @RequestBody ReservationRequestDTO reservationRequest) {
        ReservationDTO updatedReservation = reservationService.updateReservation(customerId, reservationId, reservationRequest);
        return updatedReservation != null ?
                ResponseEntity.ok().body(updatedReservation) :
                ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{reservationId}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> deleteReservation(@PathVariable Long reservationId) {
        boolean isDeleted = reservationService.deleteReservation(reservationId);
        return isDeleted ?
                ResponseEntity.ok().body("Reservation with ID: " + reservationId + " has been deleted.") :
                ResponseEntity.status(HttpStatus.NOT_FOUND).body("Reservation with ID: " + reservationId + " not found.");
    }

    @PutMapping("/{reservationId}/payment")
    @PreAuthorize("hasAuthority('CLIENT')")
    public ResponseEntity<String> paymentReservation(@PathVariable Long reservationId) {
        boolean isPaid = reservationService.paymentReservation(reservationId);
        return isPaid ?
                ResponseEntity.ok().body("Reservation with ID: " + reservationId + " has been paid.") :
                ResponseEntity.status(HttpStatus.NOT_FOUND).body("Reservation with ID: " + reservationId + " not found.");
    }


    @PutMapping("/{reservationId}/cancel")
    @PreAuthorize("hasAuthority('CLIENT')")
    public ResponseEntity<String> cancelReservation(@PathVariable Long reservationId) {
        boolean isCancelled = reservationService.cancelReservation(reservationId);
        return isCancelled ?
                ResponseEntity.ok().body("Reservation with ID: " + reservationId + " has been cancelled.") :
                ResponseEntity.status(HttpStatus.NOT_FOUND).body("Reservation with ID: " + reservationId + " not found.");
    }

    @PostMapping("/{reservationId}/checkin")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> checkInReservation(@PathVariable Long customerId, @PathVariable Long reservationId) {
        boolean isCheckIn = reservationService.checkInProcess(customerId, reservationId);
        return isCheckIn ?
                ResponseEntity.ok().body("Reservation with ID: " + reservationId + " has been check in.") :
                ResponseEntity.status(HttpStatus.NOT_FOUND).body("Reservation with ID: " + reservationId + " check-in unsuccessfully.");
    }

    @PostMapping("/{reservationId}/checkout")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> checkOutReservation(@PathVariable Long customerId, @PathVariable Long reservationId) {
        boolean isCheckOut = reservationService.checkOutProcess(customerId, reservationId);
        return isCheckOut ?
                ResponseEntity.ok().body("Reservation with ID: " + reservationId + " has been check out.") :
                ResponseEntity.status(HttpStatus.NOT_FOUND).body("Reservation with ID: " + reservationId + " check-out unsuccessfully.");
    }
}
