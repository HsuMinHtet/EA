package edu.miu.cs.cs544.security;


import edu.miu.cs.cs544.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public JwtAuthFilter authFilter(){
        return  new JwtAuthFilter();
    }

    // User Creation
    @Bean
    public UserDetailsService userDetailsService() {
        return new UserService();
    }


    // Configuring HttpSecurity
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers( "/api/customers/create","/api/admins/create", "/api/users/login","/api/users/create").permitAll()
                .and()
//                .requestMatchers( "/api/customers","/api/customers/{id}","api/users","api/users/{id}","/api/{id}/reservations","/api/products/create","/api/customers/create","/api/admins/create", "/api/users/login").permitAll()
//                .and()
                .authorizeHttpRequests().requestMatchers("/api/{id}/reservations","/api/{cid}/reservations/{rid}/payment","/api/{cid}/reservations/{rid}/checkin","/api/{cid}/reservations/{rid}/checkout","/api/{cid}/reservations/{rid}/cancel","/api/{id}/reservations/{r_id}","/api/{id}/reservations/{r_id}/payment","/api/products/create","/api/products","api/users","/api/customers","api/users/{id}","/api/customers/{id}","/api/products/{id}","/api/users/logout").authenticated()
                .and()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(authFilter(), UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    // Password Encoding
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
        authenticationProvider.setUserDetailsService(userDetailsService());
        authenticationProvider.setPasswordEncoder(passwordEncoder());
        return authenticationProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }


}