package edu.miu.cs.cs544.DTO;

import lombok.Data;

@Data
public class ReservationProductsDTO {
    private Long productId;
    private int occupants;
}
