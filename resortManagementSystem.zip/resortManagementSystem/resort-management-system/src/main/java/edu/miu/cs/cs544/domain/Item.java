package edu.miu.cs.cs544.domain;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;

@Entity
@Table(name = "items")
@Data
public class Item {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private int numberOfOccupants;
	
	private LocalDate checkInDate;

	private LocalDate checkOutDate;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "reservation_id")
	private Reservation reservation;

	@Embedded
	private AuditData auditData;

	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product product;
}
