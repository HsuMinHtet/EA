package edu.miu.cs.cs544.service;

import edu.miu.cs.cs544.DTO.ProductDTO;
import edu.miu.cs.cs544.domain.Product;
import edu.miu.cs.cs544.repository.ProductRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public interface ProductService {

    public ProductDTO getProductById(Long id);

    public List<ProductDTO> getAllProducts();

    public ProductDTO createProduct(ProductDTO productDTO);

    public ProductDTO updateProduct(Long id, ProductDTO productDTO);

    public boolean deleteProduct(Long id);

    public ProductDTO convertToDTO(Product product);

    public Product convertToEntity(ProductDTO productDTO);
}