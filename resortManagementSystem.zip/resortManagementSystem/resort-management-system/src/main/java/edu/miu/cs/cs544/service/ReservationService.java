package edu.miu.cs.cs544.service;

import edu.miu.cs.cs544.DTO.ReservationDTO;
import edu.miu.cs.cs544.DTO.ReservationDetailDTO;
import edu.miu.cs.cs544.DTO.ReservationRequestDTO;

import java.util.List;


public interface ReservationService {
     // Retrieve a reservation by its unique identifier
     ReservationDetailDTO getReservationById(Long id);

     // Retrieve a list of all reservations
     List<ReservationDTO> getAllReservations();

     // Create a new reservation for a given customer
     ReservationDTO createReservation(Long customerId, ReservationRequestDTO reservationRequest);

     // Update an existing reservation based on customer and reservation identifiers
     ReservationDTO updateReservation(Long customerId, Long reservationId, ReservationRequestDTO reservationRequest);

     // Delete a reservation by its unique identifier
     boolean deleteReservation(Long id);

     // Payment a reservation by its unique identifier
     boolean paymentReservation(Long id);

     // Cancel a reservation by its unique identifier
     boolean cancelReservation(Long id);

     // Process check-in for a reservation
     boolean checkInProcess(Long customerId, Long reservationId);

     // Process check-out for a reservation
     boolean checkOutProcess(Long customerId, Long reservationId);

}