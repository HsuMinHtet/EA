package edu.miu.cs.cs544.util;

import edu.miu.cs.cs544.domain.AuditData;
import edu.miu.cs.cs544.domain.AuditData;
import java.time.LocalDateTime;

public class AuditDataUpdate {

    public static AuditData populateAuditData(String loggedInUser) {
        LocalDateTime now = LocalDateTime.now();
        AuditData auditData = new AuditData();
        auditData.setUpdatedBy(loggedInUser);
        auditData.setUpdatedOn(now);

        return auditData;
    }
}