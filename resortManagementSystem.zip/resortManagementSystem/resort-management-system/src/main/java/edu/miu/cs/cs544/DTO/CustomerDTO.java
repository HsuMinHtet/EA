package edu.miu.cs.cs544.DTO;

import edu.miu.cs.cs544.domain.Address;
import edu.miu.cs.cs544.domain.AuditData;
import edu.miu.cs.cs544.domain.User;
import edu.miu.cs.cs544.domain.UserType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerDTO {
    private Long id;

    private String firstName;

    private String lastName;

    private String email;

    private User user;

    private AuditData auditData;

    private Address billingAddress;

    private Address physicalAddress;

}