package edu.miu.cs.cs544.service;

import edu.miu.cs.cs544.DTO.*;
import edu.miu.cs.cs544.domain.*;
import edu.miu.cs.cs544.logging.Logger;
import edu.miu.cs.cs544.repository.CustomerRepository;
import edu.miu.cs.cs544.repository.ItemRepository;
import edu.miu.cs.cs544.repository.ProductRepository;
import edu.miu.cs.cs544.repository.ReservationRepository;
import edu.miu.cs.cs544.util.AuditDataCreate;
import edu.miu.cs.cs544.util.AuditDataUpdate;
import jakarta.transaction.Transactional;
import lombok.NonNull;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

import static edu.miu.cs.cs544.domain.ReservationStatus.*;

@Service
@Transactional
public class ReservationServiceImpl implements ReservationService {
    @Autowired
    private ReservationRepository reservationRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private ItemRepository itemRepository;
    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ModelMapper modelMapper;

    //private static final Logger logger = LoggerFactory.getLogger(ReservationServiceImpl.class);
    @Autowired
    private Logger logger;

    // Get All Reservations
    public List<ReservationDTO> getAllReservations() {
        List<Reservation> reservations = reservationRepository.findAllReservation();

        return reservations.stream()
                .map(this::getData)
                .collect(Collectors.toList());
    }

    //Get Reservations by reservation id
    public ReservationDetailDTO getReservationById(Long id) {
        Optional<Reservation> optionalReservation = Optional.ofNullable(reservationRepository.findReservationById(id));
        return optionalReservation.map(this::getDetailData)
                .orElseThrow(() -> new NoSuchElementException("Reservation not found for id: " + id));
    }

    // Implementation of createReservation method
    public ReservationDTO createReservation(@PathVariable Long customerId, ReservationRequestDTO reservationRequest) {

        try {
            Reservation reservation = new Reservation();
            reservation.setTotalAmount(0.0);
            reservation.setStatus(NEW);

            int noOfReservationDays = (int) ChronoUnit.DAYS.between(reservationRequest.getCheckInDate(), reservationRequest.getCheckOutDate());
            Optional<Customer> customerOptional = customerRepository.findById(customerId);

            //verify for customer exist, check-Out>check-In and to choose at least one product
            if (!(verfifyReservation(customerOptional, reservationRequest, noOfReservationDays))) {
                logger.error("Validation failed for reservation with customer ID: {}");
                return null;
            }

            List<Item> items = new ArrayList<>();

            // Check available capacity and create items
            for (ReservationProductsDTO reservationProductsDTO : reservationRequest.getReservationProducts()) {
                // Check if product exists
                Optional<Product> productOptional = productRepository.findById(reservationProductsDTO.getProductId());
                if (productOptional.isEmpty()) {
                    logger.error("Product not found for ID: {}");
                    return null;
                }

                Product product = productOptional.get();
                int maxCapacity = product.getMaxCapacity();

                // Check maximum capacity
                if (maxCapacity >= reservationProductsDTO.getOccupants()) {
                    // Call method to check available product reservation date
                    if (!(verifyAvaiableProduct(product, reservationRequest.getCheckInDate(), reservationRequest.getCheckOutDate(), 0L))) {
                        logger.error("No available reservation for product with ID: {}");
                        return null;
                    }

                    Item item = new Item();
                    item.setCheckInDate(reservationRequest.getCheckInDate());
                    item.setCheckOutDate(reservationRequest.getCheckOutDate());
                    item.setReservation(reservation);
                    item.setNumberOfOccupants(reservationProductsDTO.getOccupants());
                    item.setProduct(product);
                    String loggedInUser = SecurityContextHolder.getContext().getAuthentication().getName();
                    AuditData auditData = AuditDataCreate.populateAuditData(loggedInUser);
                    item.setAuditData(auditData);
                    itemRepository.save(item);
                    items.add(item);

                    // Calculate and add the price
                    reservation.setTotalAmount(reservation.getTotalAmount() + product.getNightlyRate() * noOfReservationDays);
                } else {
                    logger.error("Occupants exceed the max capacity for product with ID: {}");
                    return null;
                }
            }

            reservation.setFlag(true);
            reservation.setItems(items);
            reservation.setCustomer(customerOptional.get());
            String loggedInUser = SecurityContextHolder.getContext().getAuthentication().getName();
            AuditData auditData = AuditDataCreate.populateAuditData(loggedInUser);
            reservation.setAuditData(auditData);
            Reservation savedReservation = reservationRepository.save(reservation);
            return getData(savedReservation);
        } catch (Exception e) {
            // Log the exception
            logger.error("An error occurred while creating reservation");

            // Rethrow the exception or handle it as needed
            throw new RuntimeException("An error occurred while creating reservation", e);
        }
    }


    // Implementation of updateReservation method
    public ReservationDTO updateReservation(Long customerId, Long id, ReservationRequestDTO reservationRequest) {
        try {
            Optional<Reservation> optionalReservation = reservationRepository.findById(id);
            Optional<Customer> optionalCustomer = customerRepository.findById(customerId);
            int noOfReservationDays = (int) ChronoUnit.DAYS.between(reservationRequest.getCheckInDate(), reservationRequest.getCheckOutDate());
            Reservation reservation = optionalReservation.get();
            reservation.setTotalAmount(0.0);
            reservation.setStatus(PLACED);
            List<Item> items = new ArrayList<>();

            //verify for customer exist, check-Out>check-In and to choose at least one product
            if (!(verfifyReservation(optionalCustomer, reservationRequest, noOfReservationDays))) {
                logger.error("Validation failed for reservation with customer ID: {}");
                return null;
            }

            //check reservation id
            if (optionalReservation.isEmpty()) {
                logger.error("There is no such reservation for ID:");
                return null;
            }

            //check status
            if (optionalReservation.get().getStatus().equals(CANCELLED) || optionalReservation.get().getStatus().equals(ARRIVED) || (optionalReservation.get().getStatus().equals(DEPARTED))) {
                logger.error("Cannot update reservation with status: {}");
                return null;
            }
            //call Item validate method
            if (!validateTheRequestedItems(id, reservationRequest)) {
                return null;
            }
            //Get existing items
            List<Item> existingItems = reservationRepository.findItemsById(reservation.getId());
            int numExistingItems = existingItems.size();
            int addItemsCount = 0;
            int updateItemsCount = 0;
            int deleteItemsCount = 0;
            //Get New items
            int numNewItems = reservationRequest.getReservationProducts().size();
            //reduce existing count
            if (numExistingItems > numNewItems) {
                System.out.println("You can't reduce the existing items count.");
                return null;
            }
            //update and add
            if (numExistingItems < numNewItems) {
                addItemsCount = numNewItems - numExistingItems;
                updateItemsCount = numExistingItems;
            }
            //update only
            if (numExistingItems == numNewItems) {
                updateItemsCount = numExistingItems;
            }

            //update at existing
            if (updateItemsCount != 0) {
                for (Item existingItem : reservationRepository.findItemsById(reservation.getId())) {
                    updateItemsCount = updateItemsCount - 1;
                    existingItem.setCheckInDate(reservationRequest.getCheckInDate());
                    existingItem.setCheckOutDate(reservationRequest.getCheckOutDate());
                    existingItem.setReservation(reservation);
                    existingItem.setNumberOfOccupants(reservationRequest.getReservationProducts().get(updateItemsCount).getOccupants());
                    existingItem.setProduct(productRepository.findById(reservationRequest.getReservationProducts().get(updateItemsCount).getProductId()).get());
                    itemRepository.updateItemById(existingItem.getProduct().getId(), existingItem.getNumberOfOccupants(), existingItem.getCheckInDate(), existingItem.getCheckOutDate(), existingItem.getId());
                    items.add(existingItem);
                    //calculate and add the price
                    reservation.setTotalAmount(reservation.getTotalAmount() + productRepository.findById(reservationRequest.getReservationProducts().get(updateItemsCount).getProductId()).get().getNightlyRate() * noOfReservationDays);
                }
            }
            //add new Item
            if (addItemsCount != 0) {
                while (addItemsCount != 0) {
                    Item item = new Item();
                    item.setCheckInDate(reservationRequest.getCheckInDate());
                    item.setCheckOutDate(reservationRequest.getCheckOutDate());
                    item.setReservation(reservation);
                    item.setNumberOfOccupants(reservationRequest.getReservationProducts().get(numNewItems - addItemsCount).getOccupants());
                    item.setProduct(productRepository.findById(reservationRequest.getReservationProducts().get(numNewItems - addItemsCount).getProductId()).get());
                    String loggedInUser = SecurityContextHolder.getContext().getAuthentication().getName();
                    AuditData auditData = AuditDataUpdate.populateAuditData(loggedInUser);
                    item.setAuditData(auditData);
                    itemRepository.save(item);
                    items.add(item);
                    //calculate and add the price
                    reservation.setTotalAmount(reservation.getTotalAmount() + productRepository.findById(reservationRequest.getReservationProducts().get(numNewItems - addItemsCount).getProductId()).get().getNightlyRate() * noOfReservationDays);
                    addItemsCount--;
                }
            }

            reservation.setFlag(true);
            reservation.setItems(items);
            reservation.setCustomer(optionalCustomer.get());
            String loggedInUser = SecurityContextHolder.getContext().getAuthentication().getName();
            AuditData auditData = AuditDataUpdate.populateAuditData(loggedInUser);
            reservation.setAuditData(auditData);
            reservationRepository.updateReservationStatusAndTotalAmount(reservation.getId(), reservation.getStatus(), reservation.getTotalAmount());
            return getData(reservationRepository.findById(id).get());
        } catch (Exception e) {
            // Log the exception
            logger.error("An error occurred while updating reservation");

            // Rethrow the exception or handle it as needed
            throw new RuntimeException("An error occurred while updating reservation", e);
        }
    }


    // Implementation of deleteReservation method
    public boolean deleteReservation(Long id) {
        try {
            Reservation reservation = reservationRepository.findReservationById(id);
            if (!checkToUpdateStatus(reservation)) {
                return false;
            }
            reservationRepository.updateDeleteFlagById(id);
            return true;
        } catch (Exception e) {
            // Log the exception
            logger.error("An error occurred while deleting reservation with ID: {}");

            // Rethrow the exception or handle it as needed
            throw new RuntimeException("An error occurred while deleting reservation", e);
        }
    }

    // Implementation of paymentReservation method
    public boolean paymentReservation(Long id) {
        try {
            Reservation reservation = reservationRepository.findReservationById(id);
            if (!checkToUpdateStatus(reservation)) {
                return false;
            }
            reservationRepository.updateStatusProcessed(id);
            return true;
        } catch (Exception e) {
            // Log the exception
            logger.error("An error occurred while processing payment for reservation with ID: {}");

            // Rethrow the exception or handle it as needed
            throw new RuntimeException("An error occurred while processing payment for reservation", e);
        }
    }

    // Implementation of cancelReservation method
    public boolean cancelReservation(Long id) {
        try {
            Reservation reservation = reservationRepository.findReservationById(id);
            if (!checkToUpdateStatus(reservation)) {
                return false;
            }
            reservationRepository.updateStatusCancelled(id);
            return true;
        } catch (Exception e) {
            // Log the exception
            logger.error("An error occurred while processing payment for reservation with ID: {}");

            // Rethrow the exception or handle it as needed
            throw new RuntimeException("An error occurred while processing payment for reservation", e);
        }
    }


    // Implementation of checkInProcess method
    public boolean checkInProcess(Long customerId, Long reservationId) {
        try {
            Reservation reservation = reservationRepository.findReservationById(reservationId);
            //check reservation exist
            if (reservation == null) {
                logger.error("There is no data.");
                return false;
            }

            //check item
            List<Item> items = reservationRepository.findItemsById(reservationId);
            if (items.isEmpty()) {
                logger.error("There is no data to Check In.");
                return false;
            }
            //check reservation status
            if (!(reservation.getStatus().equals(PROCESSED))) {
                logger.error("This status cannot be check in.");
                return false;
            }
            //check today date and reservation check-in and check-out date
            for (Item i : items) {
                if (LocalDate.now().isBefore(i.getCheckInDate())) {
                    logger.error("This too early to check in.");
                    return false;
                }
                if (LocalDate.now().isAfter(i.getCheckOutDate())) {
                    logger.error("This over due to check in.");
                    return false;
                }
            }
            reservationRepository.updateStatusArrived(reservationId);
            return true;
        } catch (Exception e) {
            // Log the exception
            logger.error("An error occurred while processing check-in for reservation ID: {}");

            // Rethrow the exception or handle it as needed
            throw new RuntimeException("An error occurred while processing check-in for reservation", e);
        }
    }

    // Implementation of checkOutProcess method
    public boolean checkOutProcess(Long customerId, Long reservationId) {
        try {
            Reservation reservation = reservationRepository.findReservationById(reservationId);
            //check reservation exist
            if (reservation == null) {
                logger.error("There is no data.");
                return false;
            }

            //check item
            List<Item> items = reservationRepository.findItemsById(reservationId);
            if (items.isEmpty()) {
                logger.error("There is no data to Check Out.");
                return false;
            }
            //check reservation status
            if (!(reservation.getStatus().equals(ReservationStatus.ARRIVED))) {
                logger.error("This status cannot be check Out After check In.");
                return false;
            }
            //check today date and reservation check-in and check-out date
            for (Item i : items) {
                if (LocalDate.now().isBefore(i.getCheckInDate())) {
                    logger.error("Please check in first!.");
                    return false;
                }
                if (LocalDate.now().isAfter(i.getCheckOutDate())) {
                    logger.error("This over due to check out.");
                    return false;
                }
            }
            reservationRepository.updateStatusDeparted(reservationId);
            return true;
        } catch (Exception e) {
            // Log the exception
            logger.error("An error occurred while processing check-out for reservation ID: {}");

            // Rethrow the exception or handle it as needed
            throw new RuntimeException("An error occurred while processing check-out for reservation", e);
        }
    }

    //helper methods
    ///////////////////////////////////////////////////////////////////////////
    //check to update the reservation status
    private boolean checkToUpdateStatus(Reservation reservation) {
        //check reservation exist
        if (reservation == null) {
            logger.error("No reservation found for ID: {}");
            return false;
        }
        //check status to be cancelled.
        if ((reservation.getStatus().equals(PROCESSED)) || (reservation.getStatus().equals(ARRIVED)) || (reservation.getStatus().equals(DEPARTED))) {
            logger.error("Cannot cancel reservation with status:" + reservation.getStatus());
            return false;
        }
        return true;
    }

    // Helper method to verify reservation details
    private boolean verfifyReservation(Optional<Customer> customerOptional, ReservationRequestDTO reservationRequest, int noOfReservationDays) {
        // Check check-in date < check-out date
        if (noOfReservationDays <= 0) {
            logger.error("Check again for your check-in and check-out date");
            return false;
        }

        //Check check-in / check-out date can onl be future for register and update
        if (reservationRequest.getCheckInDate().isBefore(LocalDate.now())) {
            logger.error("Check-In/Check-out date should be future!");
            return false;
        }

        // Check if customer exists
        if (customerOptional.isEmpty()) {
            logger.error("There is no such customer");
            return false;
        }

        // Check to have at least one product
        if (reservationRequest.getReservationProducts().isEmpty()) {
            logger.error("Please choose one product to make a reservation");
            return false;
        }
        return true;
    }

    // Helper method to validate requested items during update
    private boolean verifyAvaiableProduct(@NonNull Product product, LocalDate newCheckIn, LocalDate newCheckOut, Long reservationId) {
        //get items by Product Id
        List<Item> items = new ArrayList<>();

        //checking for create process
        if (reservationId == 0) {
            items = reservationRepository.findItemsByProductId(product.getId());
        }

        //checking for update process
        if (reservationId != 0) {
            items = reservationRepository.findItemsByProductIdNoReservationId(product.getId(), reservationId);
        }

        //no reserve data yet for this product
        if (items.isEmpty())
            return true;
        for (Item item : items) {
            //get existing Check In/Out date by items
            LocalDate existingCheckIn = item.getCheckInDate();
            LocalDate existingCheckOut = item.getCheckOutDate();
            // Check available
            if (newCheckIn.isBefore(existingCheckOut) && newCheckOut.isAfter(existingCheckIn)) {
                return false;
            }
        }
        return true;
    }

    //to get ReservationDTO
    private ReservationDTO getData(Reservation reservation) {
        ReservationDTO reservationDTO = new ReservationDTO();
        reservationDTO.setReservationId(reservation.getId());
        reservationDTO.setTotalAmount(reservation.getTotalAmount());
        reservationDTO.setStatus(reservation.getStatus());
        CustomerDTO customerDTO = convertToDTO(reservation.getCustomer());
        reservationDTO.setCustomerId(customerDTO.getId());
        reservationDTO.setUserName(customerDTO.getUser().getUserName());

        return reservationDTO;
    }

    //to get ReservationDetailDTO
    private ReservationDetailDTO getDetailData(Reservation reservation) {
        ReservationDetailDTO reservationDetailDTO = new ReservationDetailDTO();
        reservationDetailDTO.setReservationId(reservation.getId());
        reservationDetailDTO.setTotalAmount(reservation.getTotalAmount());
        reservationDetailDTO.setStatus(reservation.getStatus());
        CustomerDTO customerDTO = convertToDTO(reservation.getCustomer());
        reservationDetailDTO.setCustomerId(customerDTO.getId());
        reservationDetailDTO.setUserName(customerDTO.getUser().getUserName());
        reservationDetailDTO.setCheckInDate(reservation.getItems().get(0).getCheckInDate());
        reservationDetailDTO.setCheckOutDate(reservation.getItems().get(0).getCheckOutDate());
        List<ReservationProductsDTO> reservationProductsDTOS = new ArrayList<>();
        for (Item i : reservation.getItems()) {
            ReservationProductsDTO reservationProductsDTO = new ReservationProductsDTO();
            reservationProductsDTO.setProductId(i.getProduct().getId());
            reservationProductsDTO.setOccupants(i.getNumberOfOccupants());
            reservationProductsDTOS.add(reservationProductsDTO);
        }
        reservationDetailDTO.setReservationProducts(reservationProductsDTOS);
        return reservationDetailDTO;
    }

    // Helper method to verify request item
    private boolean validateTheRequestedItems(Long id, ReservationRequestDTO reservationRequest) {
        Optional<Reservation> optionalReservation = reservationRepository.findById(id);
        //inside the product list
        for (ReservationProductsDTO reservationProductsDTO : reservationRequest.getReservationProducts()) {
            Optional<Product> productOptional = productRepository.findById(reservationProductsDTO.getProductId());
            //check product exist
            if (productOptional.isEmpty()) {
                logger.error("There is no such product");
                return false;
            }
            Product product = productOptional.get();
            int maxCapacity = product.getMaxCapacity();
            //check maximum capacity
            if (maxCapacity < reservationProductsDTO.getOccupants()) {
                logger.error("This occupants are over the max capacity");
                return false;
            }
            //call method to check available product reservation date for update
            if (!verifyAvaiableProduct(product, reservationRequest.getCheckInDate(), reservationRequest.getCheckOutDate(), optionalReservation.get().getId())) {
                logger.error("There is no available reservation for this product");
                return false;
            }
        }
        return true;
    }

    // Implementation of convertToDTO method for Reservati
    public ReservationDTO convertToDTO(Reservation reservation) {
        return modelMapper.map(reservation, ReservationDTO.class);
    }

    // Implementation of convertToDTO method for Customer
    public CustomerDTO convertToDTO(Customer customer) {
        return modelMapper.map(customer, CustomerDTO.class);
    }

}