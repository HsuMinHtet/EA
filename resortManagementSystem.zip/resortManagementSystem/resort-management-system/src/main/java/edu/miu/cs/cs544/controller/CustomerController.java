//package edu.miu.cs.cs544.controller;
//
//import edu.miu.cs.cs544.DTO.CustomerDTO;
//import edu.miu.cs.cs544.domain.Address;
//import edu.miu.cs.cs544.service.AddressServiceImpl;
//import edu.miu.cs.cs544.service.CustomerService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.NoSuchElementException;
//
//@RestController
//@RequestMapping("/api/customers")
//public class CustomerController {
//
//    @Autowired
//    private CustomerService customerService;
//
//    @Autowired
//    private AddressServiceImpl addressService;
//
////    @GetMapping("/{id}")
////    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable Long id) {
////        CustomerDTO customerDTO = customerService.getCustomerById(id);
////        return ResponseEntity.ok(customerDTO);
////    }
//
//    @GetMapping("/{id}")
//    public ResponseEntity<?> getCustomerById(@PathVariable Long id) {
//        try {
//            CustomerDTO customerDTO = customerService.getCustomerById(id);
//            return ResponseEntity.ok(customerDTO);
//        } catch (NoSuchElementException e) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with ID: " + id);
//        }
//    }
//
//    @GetMapping
//    @PreAuthorize("hasAuthority('ADMIN')")
//    public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
//        List<CustomerDTO> customers = customerService.getAllCustomers();
//        return ResponseEntity.ok(customers);
//    }
//
//    @PostMapping("/create")
//    public ResponseEntity<CustomerDTO> createCustomer(@RequestBody CustomerDTO customerDTO) {
//        CustomerDTO createdCustomer = customerService.createCustomer(customerDTO);
//        return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
//    }
//
//    @PutMapping("/{id}")
//    @PreAuthorize("hasAuthority('CLIENT')")
//    public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable Long id, @RequestBody CustomerDTO customerDTO) {
//        CustomerDTO updatedCustomer = customerService.updateCustomer(id, customerDTO);
//        if (updatedCustomer != null) {
//            return ResponseEntity.ok(updatedCustomer);
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
//
//    @DeleteMapping("/{id}")
//    public ResponseEntity<String> deleteCustomer(@PathVariable Long id) {
//        boolean isDeleted = customerService.deleteCustomer(id);
//        if (isDeleted) {
//            return ResponseEntity.ok("Customer with ID: " + id + " has been deleted.");
//        } else {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer with ID: " + id + " not found.");
//        }
//    }
//
//    //==================address==========
//    @GetMapping("{c_id}/address/{id}")
//    public ResponseEntity<Address> getAddressById(@PathVariable Long id) {
//        Address address = addressService.getAddressById(id);
//        return ResponseEntity.ok(address);
//    }
//
//    @PostMapping("{c_id}/address/create")
//    public ResponseEntity<Address> createAddress(@RequestBody Address address) {
//        Address createdAddress = addressService.createAddress(address);
//        return new ResponseEntity<>(createdAddress, HttpStatus.CREATED);
//    }
//
//    @PutMapping("{c_id}/address/{id}")
//    public ResponseEntity<Address> updateAddress(@PathVariable Long id, @RequestBody Address address) {
//        Address updatedAddress = addressService.updateAddress(id, address);
//        if (updatedAddress != null) {
//            return ResponseEntity.ok(updatedAddress);
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
//
//    @DeleteMapping("{c_id}/address/{id}")
//    public ResponseEntity<String> deleteAddress(@PathVariable Long id) {
//        boolean isDeleted = addressService.deleteAddress(id);
//        if (isDeleted) {
//            return ResponseEntity.ok("Address with ID: " + id + " has been deleted.");
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
//}

package edu.miu.cs.cs544.controller;

import edu.miu.cs.cs544.DTO.CustomerDTO;
import edu.miu.cs.cs544.domain.Address;
import edu.miu.cs.cs544.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

//    @Autowired
//    private AddressServiceImpl addressService;

    @GetMapping("/{id}")
    public ResponseEntity<?> getCustomerById(@PathVariable Long id) {
        try {
            CustomerDTO customerDTO = customerService.getCustomerById(id);
            return ResponseEntity.ok(customerDTO);
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found with ID: " + id);
        }
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
        List<CustomerDTO> customers = customerService.getAllCustomers();
        return ResponseEntity.ok(customers);
    }

    @PostMapping("/create")
    public ResponseEntity<CustomerDTO> createCustomer(@RequestBody CustomerDTO customerDTO) {
        CustomerDTO createdCustomer = customerService.createCustomer(customerDTO);
        return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('CLIENT')")
    public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable Long id, @RequestBody CustomerDTO customerDTO) {
        CustomerDTO updatedCustomer = customerService.updateCustomer(id, customerDTO);
        if (updatedCustomer != null) {
            return ResponseEntity.ok(updatedCustomer);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCustomer(@PathVariable Long id) {
        boolean isDeleted = customerService.deleteCustomer(id);
        if (isDeleted) {
            return ResponseEntity.ok("Customer with ID: " + id + " has been deleted.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer with ID: " + id + " not found.");
        }
    }

//    @GetMapping("{c_id}/address/{id}")
//    public ResponseEntity<Address> getAddressById(@PathVariable Long id) {
//        Address address = addressService.getAddressById(id);
//        return ResponseEntity.ok(address);
//    }
//
//    @PostMapping("{c_id}/address/create")
//    public ResponseEntity<Address> createAddress(@RequestBody Address address) {
//        Address createdAddress = addressService.createAddress(address);
//        return new ResponseEntity<>(createdAddress, HttpStatus.CREATED);
//    }
//
//    @PutMapping("{c_id}/address/{id}")
//    public ResponseEntity<Address> updateAddress(@PathVariable Long id, @RequestBody Address address) {
//        Address updatedAddress = addressService.updateAddress(id, address);
//        if (updatedAddress != null) {
//            return ResponseEntity.ok(updatedAddress);
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
//
//    @DeleteMapping("{c_id}/address/{id}")
//    public ResponseEntity<String> deleteAddress(@PathVariable Long id) {
//        boolean isDeleted = addressService.deleteAddress(id);
//        if (isDeleted) {
//            return ResponseEntity.ok("Address with ID: " + id + " has been deleted.");
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
//
//    @ExceptionHandler(NoSuchElementException.class)
//    public ResponseEntity<String> handleNoSuchElementException(NoSuchElementException e) {
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
//    }
}