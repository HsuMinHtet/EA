package edu.miu.cs.cs544.DTO;

import edu.miu.cs.cs544.domain.AuditData;
import edu.miu.cs.cs544.domain.User;
import edu.miu.cs.cs544.domain.UserType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminDTO {

    private Long id;

    private String firstName;

    private String lastName;

    private String email;

    private User user;

    private AuditData auditData;
}