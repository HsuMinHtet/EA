package edu.miu.cs.cs544.DTO;

import edu.miu.cs.cs544.DTO.CustomerDTO;
import edu.miu.cs.cs544.DTO.ItemDTO;
import edu.miu.cs.cs544.domain.ReservationStatus;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

import java.util.List;
@Data
public class ReservationDTO {

    private Long reservationId;
    @Enumerated(EnumType.STRING)
    private ReservationStatus status;
    private Long customerId;
    private String userName;
    private double totalAmount;


}