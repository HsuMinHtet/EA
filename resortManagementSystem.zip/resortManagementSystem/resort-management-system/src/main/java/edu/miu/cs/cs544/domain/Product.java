package edu.miu.cs.cs544.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String description;

    private String excerpt;

    private double nightlyRate;

    private int maxCapacity;

    @Enumerated(EnumType.STRING)
    private ProductType type;

    @Embedded
    private AuditData auditData;

}
