package edu.miu.cs.cs544.DTO;

import edu.miu.cs.cs544.domain.ReservationStatus;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class ReservationDetailDTO {

    private Long reservationId;
    @Enumerated(EnumType.STRING)
    private ReservationStatus status;
    private double totalAmount;
    private Long customerId;
    private String userName;
    private List<ReservationProductsDTO> reservationProducts;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;

    public ReservationDetailDTO() {
    }

    public ReservationDetailDTO(Long reservationId, ReservationStatus status, double totalAmount, Long customerId, String userName) {
        this.reservationId = reservationId;
        this.status = status;
        this.totalAmount = totalAmount;
        this.customerId = customerId;
        this.userName = userName;
    }
}
