package edu.miu.cs.cs544.service;

import edu.miu.cs.cs544.DTO.CustomerDTO;
import edu.miu.cs.cs544.domain.*;
import edu.miu.cs.cs544.repository.CustomerRepository;
import edu.miu.cs.cs544.repository.UserRepository;
import edu.miu.cs.cs544.util.AuditDataCreate;
import edu.miu.cs.cs544.util.AuditDataUpdate;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private PasswordEncoder encoder;

    @Override
    public CustomerDTO getCustomerById(Long id) {
        return customerRepository.findById(id)
                .map(customer -> convertToDTO(customer))
                .orElseThrow(() -> new NoSuchElementException("Customer not found"));
    }

    @Override
    public List<CustomerDTO> getAllCustomers() {
        List<Customer> customers = customerRepository.findAll();
        return customers.stream()
                .map(customer -> modelMapper.map(customer, CustomerDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public CustomerDTO createCustomer(CustomerDTO requestDTO) {

        if(userRepository.findByUserName(requestDTO.getUser().getUserName()).isPresent()){
            throw new IllegalArgumentException("User with this username already exists.");
        }
        Customer customer = new Customer();
        customer.setFirstName(requestDTO.getFirstName());
        customer.setLastName(requestDTO.getLastName());
        customer.setEmail(requestDTO.getEmail());
        AuditData auditData = AuditDataCreate.populateAuditData(requestDTO.getFirstName());
        requestDTO.getUser().setType(UserType.CLIENT);
        requestDTO.getUser().setActive(true);
        requestDTO.getUser().setAuditData(auditData);
        requestDTO.getUser().setUserPass(encoder.encode(requestDTO.getUser().getUserPass()));
        customer.setUser(requestDTO.getUser());
        customer.setAuditData(auditData);
//        String loggedInUser = SecurityContextHolder.getContext().getAuthentication().getName();
        // Populate other customer fields
//        AuditData auditData = AuditUtil.populateAuditData(loggedInUser);

        requestDTO.getBillingAddress().setAuditData(auditData);
        requestDTO.getBillingAddress().getState().setAuditData(auditData);
        requestDTO.getBillingAddress().getState().getCountry().setAuditData(auditData);

        requestDTO.getPhysicalAddress().setAuditData(auditData);
        requestDTO.getPhysicalAddress().getState().setAuditData(auditData);
        requestDTO.getPhysicalAddress().getState().getCountry().setAuditData(auditData);

        customer.setBillingAddress(requestDTO.getBillingAddress());
        customer.setPhysicalAddress(requestDTO.getPhysicalAddress());

        Customer savedCustomer = customerRepository.save(customer);
        return convertToDTO(savedCustomer);
    }

    @Override
    @Transactional
    public CustomerDTO updateCustomer(Long id, CustomerDTO requestDTO) {

        Optional<Customer> optionalCustomer = customerRepository.findById(id);
        if (optionalCustomer.isPresent()) {
            Customer customer = optionalCustomer.get();
            customer.setFirstName(requestDTO.getFirstName());
            customer.setLastName(requestDTO.getLastName());
            customer.setEmail(requestDTO.getEmail());
            AuditData auditData = AuditDataUpdate.populateAuditData(requestDTO.getFirstName());
            customer.setAuditData(auditData);
            if (customer.getUser() != null) {
                customer.getUser().setAuditData(auditData);
                customer.getUser().setUserPass(encoder.encode(requestDTO.getUser().getUserPass()));
                customer.setUser(requestDTO.getUser());
            }


            if (customer.getBillingAddress() != null) {
                requestDTO.getBillingAddress().setAuditData(auditData);
                requestDTO.getBillingAddress().getState().setAuditData(auditData);
                requestDTO.getBillingAddress().getState().getCountry().setAuditData(auditData);
                customer.setBillingAddress(requestDTO.getBillingAddress());
            }

            if (customer.getPhysicalAddress() != null) {
                requestDTO.getPhysicalAddress().setAuditData(auditData);
                requestDTO.getPhysicalAddress().getState().setAuditData(auditData);
                requestDTO.getPhysicalAddress().getState().getCountry().setAuditData(auditData);
                customer.setPhysicalAddress(requestDTO.getPhysicalAddress());
            }

            // Save the updated customer entity
            Customer updatedCustomer = customerRepository.saveAndFlush(customer);
            return convertToDTO(updatedCustomer);
        } else {
            throw new NoSuchElementException("Customer not found");
        }
    }

    @Override
    public boolean deleteCustomer(Long id) {
        Optional<Customer> optionalCustomer = customerRepository.findById(id);
        if (optionalCustomer.isPresent()) {
            Customer customerToDelete = optionalCustomer.get();
            customerRepository.delete(customerToDelete);
            return true;
        } else {
            return false;
        }
    }


    @Override
    public CustomerDTO convertToDTO(Customer customer) {
        // Use modelMapper to map fields from Customer to CustomerDTO
        return modelMapper.map(customer, CustomerDTO.class);
    }

    @Override
    public Customer convertToEntity(CustomerDTO customerDTO) {
        return modelMapper.map(customerDTO, Customer.class);
    }

}


