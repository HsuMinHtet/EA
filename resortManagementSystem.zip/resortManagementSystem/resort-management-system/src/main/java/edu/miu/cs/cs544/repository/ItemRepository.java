package edu.miu.cs.cs544.repository;

import edu.miu.cs.cs544.domain.Address;
import edu.miu.cs.cs544.domain.Item;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ItemRepository extends JpaRepository<Item, Long> {
    Optional<Item> findByIdAndReservationId(Long itemId, Long reservationId);

    List<Item> findByReservationId(Long reservationId);

    @Modifying
    @Transactional
    @Query("UPDATE Item i SET i.numberOfOccupants = :numberOfOccupants, i.product.id = :product_id, i.checkInDate = :checkInDate, i.checkOutDate = :checkOutDate WHERE i.id = :id")
    void updateItemById(
            @Param("product_id") Long productId,
            @Param("numberOfOccupants") int numberOfOccupants,
            @Param("checkInDate") LocalDate checkInDate,
            @Param("checkOutDate") LocalDate checkOutDate,
            @Param("id") Long id
    );

    // Custom queries or methods if needed

}