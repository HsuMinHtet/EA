package edu.miu.cs.cs544.domain;


public enum UserType {
    ADMIN, CLIENT
}
