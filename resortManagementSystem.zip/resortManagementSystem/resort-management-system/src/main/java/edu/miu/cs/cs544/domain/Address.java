package edu.miu.cs.cs544.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Table(name = "addresses")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String line1;

	private String line2;

	private String city;
	
	private String postalCode;

	@Embedded
	private AuditData auditData;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "state_id")
	private State state;

}
