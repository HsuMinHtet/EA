package edu.miu.cs.cs544.DTO;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class ReservationRequest {
    private List<ReservationProductsDTO> reservationProducts;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
}
