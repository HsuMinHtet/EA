package edu.miu.cs.cs544.TestClassPackages.repository;

import edu.miu.cs.cs544.domain.Product;
import edu.miu.cs.cs544.domain.ProductType;
import edu.miu.cs.cs544.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


//@RunWith(SpringRunner.class)
@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
public class ProductRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private ProductRepository productRepository;

    private Product testProduct;

    // Set up data for testing
    @BeforeEach
   public void setUp() {
        // Create and persist test data for each ProductType

//        entityManager.persist(new Product(ProductType.Room));
//        entityManager.persist(new Product(ProductType.Villa));
//        entityManager.persist(new Product(ProductType.Apartment));
//        entityManager.persist(new Product(ProductType.Tent));
        testProduct = new Product(/* other properties */);
        testProduct.setMaxCapacity(100);
        entityManager.persist(testProduct);
        entityManager.flush();
    }


    @Test
    void findMaxCapacityById_WithValidId() {
        Integer expectedMaxCapacity = 100;
        Integer maxCapacity = productRepository.findMaxCapacityById(testProduct.getId());

        assertEquals(expectedMaxCapacity, maxCapacity, "Max capacity should match the expected value for the given ID");
    }

    @Test
    void findMaxCapacityById_WithInvalidId() {
        Long invalidId = -1L; // A non-existent ID
        Integer maxCapacity = productRepository.findMaxCapacityById(invalidId);

        assertNull(maxCapacity, "Method should return null for non-existent ID");
    }

    @Test
    public void findByType_WithRoomType() {
        testFindByType(ProductType.Room);
    }

    @Test
    public void findByType_WithVillaType() {
        testFindByType(ProductType.Villa);
    }

    @Test
   public void findByType_WithApartmentType() {
        testFindByType(ProductType.Apartment);
    }

    @Test
    public void findByType_WithTentType() {
        testFindByType(ProductType.Tent);
    }

    private void testFindByType(ProductType type) {
        //List<Product> products = productRepository.findByType(type);
        List<Product> products =null;
        assertFalse(products.isEmpty(), "Expected non-empty list of products for type " + type);
        products.forEach(product -> assertEquals(type, product.getType(), "Product type should match " + type));
    }


}
