package edu.miu.cs.cs544.TestClassPackages.service;

import edu.miu.cs.cs544.DTO.ItemDTO;
import edu.miu.cs.cs544.domain.Item;
import edu.miu.cs.cs544.domain.Reservation;
import edu.miu.cs.cs544.repository.ItemRepository;
import edu.miu.cs.cs544.repository.ReservationRepository;
import edu.miu.cs.cs544.service.ItemServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ItemServiceImplTest {

    @Mock
    private ItemRepository itemRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private ItemServiceImpl itemService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
   public void createItem_SuccessfulCreation() {
        Long validReservationId = 1L;
        ItemDTO itemDTO = new ItemDTO(); // Assuming ItemDTO is the DTO class
        Item item = new Item(); // Assuming Item is the entity class
        Reservation reservation = new Reservation(); // Assuming Reservation is the entity class

        when(reservationRepository.findById(validReservationId)).thenReturn(Optional.of(reservation));
        when(modelMapper.map(itemDTO, Item.class)).thenReturn(item);
        when(itemRepository.save(any(Item.class))).thenReturn(item);
        when(modelMapper.map(item, ItemDTO.class)).thenReturn(itemDTO);

        ItemDTO result = itemService.createItem(validReservationId, itemDTO);

        assertNotNull(result);
        verify(reservationRepository).findById(validReservationId);
        verify(itemRepository).save(item);
    }
    @Test
    public void createItem_ReservationNotFound() {
        Long invalidReservationId = 99L;
        ItemDTO itemDTO = new ItemDTO();

        when(reservationRepository.findById(invalidReservationId)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> {
            itemService.createItem(invalidReservationId, itemDTO);
        });

        verify(reservationRepository).findById(invalidReservationId);
        verify(itemRepository, never()).save(any(Item.class));
    }

    @Test
    public void updateItem_SuccessfulUpdate() {
        Long validReservationId = 1L;
        Long validItemId = 1L;
        ItemDTO updatedItemDTO = new ItemDTO(); // Set the necessary properties
        Item existingItem = new Item(); // Assuming Item is the entity class
        Item updatedItem = new Item(); // This will be the saved item entity

        when(itemRepository.findByIdAndReservationId(validItemId, validReservationId)).thenReturn(Optional.of(existingItem));
        when(itemRepository.save(any(Item.class))).thenReturn(updatedItem);
        when(modelMapper.map(updatedItem, ItemDTO.class)).thenReturn(updatedItemDTO);

        ItemDTO result = itemService.updateItem(validReservationId, validItemId, updatedItemDTO);

        assertNotNull(result);
        verify(itemRepository).findByIdAndReservationId(validItemId, validReservationId);
        verify(itemRepository).save(existingItem);
        // Verify that the existing item's properties are updated as expected
        // e.g., assertEquals(updatedItemDTO.getNumberOfOccupants(), existingItem.getNumberOfOccupants());
    }
    @Test
    public void updateItem_ItemOrReservationNotFound() {
        Long invalidReservationId = 99L;
        Long invalidItemId = 99L;
        ItemDTO updatedItemDTO = new ItemDTO();

        when(itemRepository.findByIdAndReservationId(invalidItemId, invalidReservationId)).thenReturn(Optional.empty());

        ItemDTO result = itemService.updateItem(invalidReservationId, invalidItemId, updatedItemDTO);

        assertNull(result);
        verify(itemRepository).findByIdAndReservationId(invalidItemId, invalidReservationId);
        verify(itemRepository, never()).save(any(Item.class));
    }
    @Test
    public void deleteItem_SuccessfulDeletion() {
        Long validReservationId = 1L;
        Long validItemId = 1L;
        Item itemToDelete = new Item(); // Assuming Item is the entity class

        when(itemRepository.findByIdAndReservationId(validItemId, validReservationId)).thenReturn(Optional.of(itemToDelete));

        boolean result = itemService.deleteItem(validReservationId, validItemId);

        assertTrue(result);
        verify(itemRepository).findByIdAndReservationId(validItemId, validReservationId);
        verify(itemRepository).delete(itemToDelete);
    }

    @Test
   public void deleteItem_ItemOrReservationNotFound() {
        Long invalidReservationId = 99L;
        Long invalidItemId = 99L;

        when(itemRepository.findByIdAndReservationId(invalidItemId, invalidReservationId)).thenReturn(Optional.empty());

        boolean result = itemService.deleteItem(invalidReservationId, invalidItemId);

        assertFalse(result);
        verify(itemRepository).findByIdAndReservationId(invalidItemId, invalidReservationId);
        verify(itemRepository, never()).delete(any(Item.class));
    }











}
