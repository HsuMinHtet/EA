package edu.miu.cs.cs544.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import edu.miu.cs.cs544.DTO.ReservationDTO;
import edu.miu.cs.cs544.DTO.ReservationDetailDTO;
import edu.miu.cs.cs544.DTO.ReservationProductsDTO;
import edu.miu.cs.cs544.DTO.ReservationRequest;
import edu.miu.cs.cs544.domain.ReservationStatus;
import edu.miu.cs.cs544.service.ReservationService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static edu.miu.cs.cs544.domain.ReservationStatus.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@WebMvcTest(ReservationController.class)
public class ReservationControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    ReservationService reservationService;

    @Autowired
    private ObjectMapper objectMapper;

    // Test for successful reservation retrieval
    @Test
   // @WithMockUser(username = "Hsu", roles = "admin")
    public void testGetReservationByIdSuccess() throws Exception{
        Mockito.when(reservationService.getReservationById(1L))
                .thenReturn(new ReservationDetailDTO(1L, NEW,999.9,1L,"Tinny"));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/1/reservations/1"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.reservationId").value(1L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.status").value("NEW"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.customerId").value(1L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.userName").value("Tinny"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.totalAmount").value(999.9));
    }

    // Test for unsuccessful reservation retrieval
    @Test
    public void testGetReservationByIdFailer() throws Exception{
        Mockito.when(reservationService.getReservationById(1L))
                .thenReturn(new ReservationDetailDTO(1L, NEW,999.9,1L,"Tinny"));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/1/reservations/1"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.reservationId").doesNotExist())
                .andExpect(MockMvcResultMatchers.jsonPath("$.status").doesNotExist())
                .andExpect(MockMvcResultMatchers.jsonPath("$.customerId").doesNotExist())
                .andExpect(MockMvcResultMatchers.jsonPath("$.firstName").doesNotExist())
                .andExpect(MockMvcResultMatchers.jsonPath("$.lastName").doesNotExist())
                .andExpect(MockMvcResultMatchers.jsonPath("$.email").doesNotExist())
                .andExpect(MockMvcResultMatchers.jsonPath("$.totalAmount").doesNotExist());
    }

    // Test for exception during reservation retrieval
    @Test
    public void testGetReservationByIdException() throws Exception{
        Mockito.when(reservationService.getReservationById(555L))
                .thenReturn(new ReservationDetailDTO(1L, NEW,999.9,1L,"Tinny"));

        mockMvc.perform(MockMvcRequestBuilders.get("/api/1/reservations/1"))
                .andExpect(MockMvcResultMatchers.status().is4xxClientError());
    }
//    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Test for successful reservation cancel
    @Test
    public void testCancelReservationSuccess() throws Exception {
        long reservationId = 1L;
        Mockito.when(reservationService.cancelReservation(reservationId))
                .thenReturn(true);
        // When
        boolean isCancelled = reservationService.cancelReservation(reservationId);
        // Then
        assertTrue(isCancelled);
    }

    // Test for unsuccessful reservation Cancel
    @Test
    public void testCancelReservationFailure() throws Exception {
        long reservationId = 55L;
        Mockito.when(reservationService.cancelReservation(reservationId))
                .thenReturn(false);
        // When
        boolean isCancelled = reservationService.cancelReservation(reservationId);
        // Then
        assertFalse(isCancelled);
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Test for successful reservation checkIn process
    @Test
    public void testCheckInReservationSuccess() throws Exception{
        long customerId = 1L;
        long reservationId = 1L;
        Mockito.when(reservationService.checkInProcess(customerId,reservationId))
                .thenReturn(true);

        // When
        boolean isCheckIn = reservationService.checkInProcess(customerId,reservationId);
        // Then
        assertTrue(isCheckIn);
    }

    // Test for unsuccessful reservation checkIn process
    @Test
    public void testCheckInReservationFailure() throws Exception{

        long customerId = 1L;
        long reservationId = 1L;
        Mockito.when(reservationService.checkInProcess(customerId,reservationId))
                .thenReturn(false);

        // When
        boolean isCheckIn = reservationService.checkInProcess(customerId,reservationId);
        // Then
        assertFalse(isCheckIn);
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Test for successful reservation checkOut process
@Test
public void testCheckOutReservationSuccess() throws Exception{
    long customerId = 1L;
    long reservationId = 1L;
    Mockito.when(reservationService.checkOutProcess(customerId,reservationId))
            .thenReturn(true);

    // When
    boolean isCheckOut = reservationService.checkOutProcess(customerId,reservationId);
    // Then
    assertTrue(isCheckOut);
}

    // Test for unsuccessful reservation checkIn process
    @Test
    public void testCheckOutReservationFailure() throws Exception{
        long customerId = 1L;
        long reservationId = 1L;
        Mockito.when(reservationService.checkOutProcess(customerId,reservationId))
                .thenReturn(false);

        // When
        boolean isCheckOut = reservationService.checkOutProcess(customerId,reservationId);
        // Then
        assertFalse(isCheckOut);
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Test for successful reservation delete(soft delete)
    @Test
    public void testDeleteReservationSuccess() throws Exception{
        long reservationId = 1L;
        Mockito.when(reservationService.deleteReservation(reservationId))
                .thenReturn(true);
        // When
        boolean isCancelled = reservationService.deleteReservation(reservationId);
        // Then
        assertTrue(isCancelled);

    }

    // Test for unsuccessful reservation checkIn process
    @Test
    public void testDeleteReservationFailure() throws Exception{
        long reservationId = 55L;
        Mockito.when(reservationService.deleteReservation(reservationId))
                .thenReturn(false);
        // When
        boolean isDeleted = reservationService.deleteReservation(reservationId);
        // Then
        assertFalse(isDeleted);
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//    @Test
//    void testMakeReservationSuccess() throws Exception {
//        // Given
//        long customerId = 1L;
//        //crete request data
//        ReservationRequest reservationRequest = new ReservationRequest();
//        reservationRequest.setCheckInDate(LocalDate.parse("2023-12-20"));
//        reservationRequest.setCheckOutDate(LocalDate.parse("2023-12-25"));
//
//        List<ReservationProductsDTO> reservationProducts = new ArrayList<>();
//        ReservationProductsDTO product1 = new ReservationProductsDTO();
//        product1.setProductId(1L);
//        product1.setOccupants(1);
//        ReservationProductsDTO product2 = new ReservationProductsDTO();
//        product2.setProductId(1L);
//        product2.setOccupants(1);
//        reservationProducts.add(product1);
//        reservationProducts.add(product2);
//
//        reservationRequest.setReservationProducts(reservationProducts);
//
//
//        Mockito.when(reservationService.createReservation(customerId,reservationRequest))
//                .thenReturn(new ReservationDTO(6L,ReservationStatus.PROCESSED,1L,"Tinny","Doe","john.doe@example.com",999.9) );
//
//        mockMvc.perform(MockMvcRequestBuilders.post("/api/1/reservations"))
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andExpect(MockMvcResultMatchers.jsonPath("$.reservationId").value(6L))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.status").value("PROCESSED"))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.customerId").value(1L))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.firstName").value("Tinny"))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.lastName").value("Doe"))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.email").value("john.doe@example.com"))
//                .andExpect(MockMvcResultMatchers.jsonPath("$.totalAmount").value(999.9));
//
//    }

}
