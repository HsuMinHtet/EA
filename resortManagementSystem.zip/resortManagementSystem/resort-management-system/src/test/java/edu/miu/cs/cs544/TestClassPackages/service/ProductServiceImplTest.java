package edu.miu.cs.cs544.TestClassPackages.service;

import edu.miu.cs.cs544.DTO.ProductDTO;
import edu.miu.cs.cs544.domain.Product;
import edu.miu.cs.cs544.repository.ProductRepository;
import edu.miu.cs.cs544.service.ProductServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ProductServiceImplTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private ProductServiceImpl productService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetProductById_Success() {
        Long productId = 1L;
        Product mockProduct = new Product(); // Assuming Product is a valid entity
        ProductDTO mockProductDTO = new ProductDTO(); // Assuming ProductDTO is a valid DTO

        when(productRepository.findById(productId)).thenReturn(Optional.of(mockProduct));
        when(modelMapper.map(mockProduct, ProductDTO.class)).thenReturn(mockProductDTO);

        ProductDTO result = productService.getProductById(productId);

        assertEquals(mockProductDTO, result);
        verify(productRepository).findById(productId);
        verify(modelMapper).map(mockProduct, ProductDTO.class);
    }

    @Test
    public void testGetProductById_NotFound() {
        Long productId = 1L;

        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> productService.getProductById(productId));
    }

    @Test
    public void testGetAllProducts() {

        Product product1 = new Product(); // Assuming Product is a valid entity
        Product product2 = new Product();
        List<Product> products = Arrays.asList(product1, product2);
        ProductDTO productDTO1 = new ProductDTO(); // Assuming ProductDTO is a valid DTO
        ProductDTO productDTO2 = new ProductDTO();

        when(productRepository.findAll()).thenReturn(products);
        when(modelMapper.map(product1, ProductDTO.class)).thenReturn(productDTO1);
        when(modelMapper.map(product2, ProductDTO.class)).thenReturn(productDTO2);

        // Act
        List<ProductDTO> result = productService.getAllProducts();

        // Assert
        assertEquals(2, result.size());
        assertTrue(result.containsAll(Arrays.asList(productDTO1, productDTO2)));
        verify(productRepository).findAll();
        verify(modelMapper, times(2)).map(any(Product.class), eq(ProductDTO.class));

    }
//    @Test
//    public void testCreateProduct() {
//        // Arrange
//        ProductDTO productDTO1 = new ProductDTO(); // Assuming ProductDTO is a valid DTO
//
//        Product product1 = new Product(); // Assuming Product is a valid entity
//
//        when(modelMapper.map(productDTO1, Product.class)).thenReturn(product1);
//
//        when(productRepository.saveAll(product1)).thenReturn(product1);
//
//        when(modelMapper.map(product1, ProductDTO.class)).thenReturn(productDTO1);
//
//        // Act
//        ProductDTO createdProducts = productService.createProduct(productDTOs);
//
//        // Assert
//        assertEquals(2, createdProducts.size());
//        assertTrue(createdProducts.containsAll(Arrays.asList(productDTO1, productDTO2)));
//        verify(modelMapper, times(productDTOs.size())).map(any(ProductDTO.class), eq(Product.class));
//        verify(productRepository).saveAll(products);
//        verify(modelMapper, times(products.size())).map(any(Product.class), eq(ProductDTO.class));
//    }

    @Test
    public void testUpdateProduct_Found() {
        // Arrange
        Long productId = 1L;
        ProductDTO productDTO = new ProductDTO(); // Assuming ProductDTO is a valid DTO
        Product existingProduct = new Product(); // Assuming Product is a valid entity
        Product updatedProduct = new Product();

        when(productRepository.findById(productId)).thenReturn(Optional.of(existingProduct));
        when(productRepository.save(existingProduct)).thenReturn(updatedProduct);
        when(modelMapper.map(updatedProduct, ProductDTO.class)).thenReturn(productDTO);

        // Act
        ProductDTO result = productService.updateProduct(productId, productDTO);

        // Assert
        assertNotNull(result);
        assertEquals(productDTO, result);
        verify(productRepository).findById(productId);
        verify(productRepository).save(existingProduct);
        verify(modelMapper).map(updatedProduct, ProductDTO.class);
    }

    @Test
    public void testUpdateProduct_NotFound() {
        // Arrange
        Long productId = 1L;
        ProductDTO productDTO = new ProductDTO(); // Assuming ProductDTO is a valid DTO

        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        // Act
        ProductDTO result = productService.updateProduct(productId, productDTO);

        // Assert
        assertNull(result);
        verify(productRepository).findById(productId);
        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    public void testDeleteProduct_Success() {
        // Arrange
        Long productId = 1L;
        Product productToDelete = new Product(); // Assuming Product is a valid entity

        when(productRepository.findById(productId)).thenReturn(Optional.of(productToDelete));
        doNothing().when(productRepository).delete(productToDelete);

        // Act
        productService.deleteProduct(productId);

        // Assert
        verify(productRepository).findById(productId);
        verify(productRepository).delete(productToDelete);
    }

    @Test
    public void testDeleteProduct_NotFound() {
        // Arrange
        Long productId = 1L;

        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(NoSuchElementException.class, () -> productService.deleteProduct(productId));
        verify(productRepository).findById(productId);
        verify(productRepository, never()).delete(any(Product.class));
    }

}
