package edu.miu.cs.cs544.services;

import edu.miu.cs.cs544.DTO.AdminDTO;
import edu.miu.cs.cs544.DTO.CustomerDTO;
import edu.miu.cs.cs544.domain.Admin;
import edu.miu.cs.cs544.domain.Customer;
import edu.miu.cs.cs544.domain.User;
import edu.miu.cs.cs544.domain.UserType;
import edu.miu.cs.cs544.repository.AdminRepository;
import edu.miu.cs.cs544.service.AdminServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AdminServiceTest {

    @Mock
    private AdminRepository adminRepository;

    @Mock
    private PasswordEncoder encoder;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private AdminServiceImpl adminService;

    @Test
    public void getAdminById_ExistingId_ShouldReturnAdminDTO() {
        // Create a sample Admin
        Admin admin = new Admin();
        admin.setId(1L);
        admin.setFirstName("John");
        admin.setLastName("Doe");
        admin.setEmail("john@example.com");

        // Mock behavior of adminRepository.findById(id)
        when(adminRepository.findById(1L)).thenReturn(Optional.of(admin));

        // Create a sample AdminDTO for mapping
        AdminDTO adminDTO = new AdminDTO();
        adminDTO.setId(1L);
        adminDTO.setFirstName("John");
        adminDTO.setLastName("Doe");
        adminDTO.setEmail("john@example.com");

        // Mock the conversion from Admin to AdminDTO
        when(modelMapper.map(any(Admin.class), any())).thenReturn(adminDTO);

        // Test getAdminById method
        AdminDTO result = adminService.getAdminById(1L);

        // Assert the result
        assertEquals("John", result.getFirstName());
        assertEquals("Doe", result.getLastName());
        assertEquals("john@example.com", result.getEmail());
        // Add more assertions based on your DTO mappings
    }

    @Test
    public void getAdminById_NonExistingId_ShouldThrowNoSuchElementException() {
        // Mock behavior of adminRepository.findById(id)
        when(adminRepository.findById(999L)).thenReturn(Optional.empty());

        // Test getAdminById method for a non-existing ID
        assertThrows(NoSuchElementException.class, () -> adminService.getAdminById(999L));
    }

    @Test
    public void createAdmin_WithValidData_ShouldCreateAdmin() {
        // Create a sample AdminDTO for creation
        AdminDTO adminDTO = new AdminDTO();
        adminDTO.setFirstName("John");
        adminDTO.setLastName("Doe");
        adminDTO.setEmail("john@example.com");

        User user = new User();
        user.setUserName("john");
        user.setUserPass("password");
        adminDTO.setUser(user);

//        // Stubbing for modelMapper.map method
        when(modelMapper.map(any(), eq(AdminDTO.class))).thenReturn(adminDTO);

        // Test createAdmin method
        AdminDTO result = adminService.createAdmin(adminDTO);

        // Assert the result
        assertEquals("John", result.getFirstName());
        assertEquals("Doe", result.getLastName());
        assertEquals("john@example.com", result.getEmail());
        assertEquals(UserType.ADMIN, result.getUser().getType());
        assertNotNull(result.getUser());
    }

    @Test
    public void updateAdmin_WithValidData_ShouldNotThrowException() {
        Long existingId = 5L;
        AdminDTO adminDTO = new AdminDTO();
        adminDTO.setFirstName("John");
        adminDTO.setLastName("Doe");
        adminDTO.setEmail("john@example.com");

        Optional<Admin> optionalAdmin = Optional.of(new Admin());
        when(adminRepository.findById(existingId)).thenReturn(optionalAdmin);

        // Mock any necessary behaviors for update operation if needed

        assertDoesNotThrow(() -> adminService.updateAdmin(existingId, adminDTO));
    }

    @Test
    public void deleteAdmin_WithExistingId_ShouldReturnTrue() {
        Long existingId = 123L;
        Optional<Admin> optionalAdmin = Optional.of(new Admin());
        when(adminRepository.findById(existingId)).thenReturn(optionalAdmin);

        assertTrue(adminService.deleteAdmin(existingId));
    }

    @Test
    public void deleteAdmin_WithNonExistingId_ShouldReturnFalse() {
        Long nonExistingId = 999L;
        when(adminRepository.findById(nonExistingId)).thenReturn(Optional.empty());

        assertFalse(adminService.deleteAdmin(nonExistingId));
    }
}