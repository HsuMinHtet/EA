package edu.miu.cs.cs544;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cs544202312ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
