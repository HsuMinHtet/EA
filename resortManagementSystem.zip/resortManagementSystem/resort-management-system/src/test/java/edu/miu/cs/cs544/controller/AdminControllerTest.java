package edu.miu.cs.cs544.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import edu.miu.cs.cs544.DTO.AdminDTO;
import edu.miu.cs.cs544.controller.AdminController;
import edu.miu.cs.cs544.service.AdminServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.NoSuchElementException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class AdminControllerTest {

    private MockMvc mockMvc;

    @Mock
    private AdminServiceImpl adminService;

    @InjectMocks
    private AdminController adminController;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(adminController)
                .setControllerAdvice(new AdminControllerExceptionHandler())
                .build();
    }

    @Test
    public void testGetAdminById_ValidId_ReturnsAdminDTO() throws Exception {
        AdminDTO adminDTO = new AdminDTO(); // Create an instance of AdminDTO with required data for testing

        // Mock the behavior of the adminService.getAdminById() method
        when(adminService.getAdminById(any(Long.class))).thenReturn(adminDTO);

        mockMvc.perform(get("/api/admins/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andDo(print());
    }

    @Test
    public void testCreateAdmin_ValidAdminDTO_ReturnsCreatedAdminDTO() throws Exception {
        AdminDTO adminDTO = new AdminDTO(); // Create an instance of AdminDTO with required data for testing

        // Mock the behavior of the adminService.createAdmin() method
        when(adminService.createAdmin(any(AdminDTO.class))).thenReturn(adminDTO);

        mockMvc.perform(post("/api/admins/create")
                        .content(objectMapper.writeValueAsString(adminDTO))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andDo(print());
    }

    @Test
    public void testUpdateAdmin_ValidIdAndAdminDTO_ReturnsUpdatedAdminDTO() throws Exception {
        AdminDTO adminDTO = new AdminDTO(); // Create an instance of AdminDTO with required data for testing

        // Mock the behavior of the adminService.updateAdmin() method
        when(adminService.updateAdmin(any(Long.class), any(AdminDTO.class))).thenReturn(adminDTO);

        mockMvc.perform(put("/api/admins/{id}", 1L)
                        .content(objectMapper.writeValueAsString(adminDTO))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andDo(print());
    }

    @Test
    public void testDeleteAdmin_ValidId_ReturnsOkMessage() throws Exception {
        // Mock the behavior of the adminService.deleteAdmin() method
        when(adminService.deleteAdmin(any(Long.class))).thenReturn(true);

        mockMvc.perform(delete("/api/admins/{id}", 1L)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    private static class AdminControllerExceptionHandler {
        @ExceptionHandler(Exception.class)
        public ResponseEntity<String> handle(Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}