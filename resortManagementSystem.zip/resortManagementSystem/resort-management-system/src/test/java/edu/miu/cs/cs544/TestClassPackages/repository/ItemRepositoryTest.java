package edu.miu.cs.cs544.TestClassPackages.repository;

import edu.miu.cs.cs544.domain.Item;
import edu.miu.cs.cs544.domain.Reservation;
import edu.miu.cs.cs544.repository.ItemRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=AutoConfigureTestDatabase.Replace.NONE)
public class ItemRepositoryTest {


    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private ItemRepository itemRepository;

    @Test
   public void findByIdAndReservationId_ItemExists() {
        // Create a sample Reservation
        Reservation reservation = new Reservation(/* set other properties */);
        reservation.setFlag(true); // Set the flag to true for this reservation
        entityManager.persist(reservation);

        // Create a sample Item associated with the Reservation
        Item item = new Item(/* set other properties */);
        item.setReservation(reservation); // Set the Reservation
        entityManager.persist(item);
        entityManager.flush();

        // Call the repository method with the item's ID and reservation's ID
        Long itemId = item.getId();
        Long reservationId = reservation.getId();
        Optional<Item> foundItem = itemRepository.findByIdAndReservationId(itemId, reservationId);

        // Assert that the item is found
        assertTrue(foundItem.isPresent(), "Item should be found");

        // Additional assertions if needed
        assertEquals(itemId, foundItem.get().getId(), "Item ID should match");
        assertEquals(reservationId, foundItem.get().getReservation().getId(), "Reservation ID should match");
    }

    @Test
    public void findByIdAndReservationId_ItemDoesNotExist() {
        // Call the repository method with non-existent IDs
        Long nonExistentItemId = 100L;
        Long nonExistentReservationId = 200L;
        Optional<Item> foundItem = itemRepository.findByIdAndReservationId(nonExistentItemId, nonExistentReservationId);

        // Assert that no item is found (the result is an empty Optional)
        assertFalse(foundItem.isPresent(), "No item should be found");
    }

    @Test
    void findByReservationId_ItemsExist() {
        // Create a sample Reservation
        Reservation reservation = new Reservation(/* set other properties */);
        entityManager.persist(reservation);

        // Create multiple sample Item objects associated with the same Reservation
        Item item1 = new Item(/* set other properties */);
        item1.setReservation(reservation);
        entityManager.persist(item1);

        Item item2 = new Item(/* set other properties */);
        item2.setReservation(reservation);
        entityManager.persist(item2);

        // Flush the changes to the database
        entityManager.flush();

        // Call the repository method to find items by Reservation ID
        Long reservationId = reservation.getId();
        List<Item> foundItems = itemRepository.findByReservationId(reservationId);

        // Assert that the correct items are found
        assertEquals(2, foundItems.size(), "Two items should be found for the Reservation");
        assertTrue(foundItems.contains(item1), "Item 1 should be in the list");
        assertTrue(foundItems.contains(item2), "Item 2 should be in the list");
    }

    @Test
    void findByReservationId_NoItemsExist() {
        // Create a sample Reservation
        Reservation reservation = new Reservation(/* set other properties */);
        entityManager.persist(reservation);

        // Call the repository method with a Reservation ID where no items exist
        Long reservationId = reservation.getId() + 1; // Use a different ID
        List<Item> foundItems = itemRepository.findByReservationId(reservationId);

        // Assert that no items are found (the list should be empty)
        assertTrue(foundItems.isEmpty(), "No items should be found for this Reservation");
    }

}
