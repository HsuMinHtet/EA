package edu.miu.cs.cs544.controller;

import edu.miu.cs.cs544.DTO.CustomerDTO;
import edu.miu.cs.cs544.service.CustomerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class CustomerControllerTest {

    @Mock
    private CustomerService customerService;

    @InjectMocks
    private CustomerController customerController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetCustomerById_ValidId_ReturnsCustomer() {
        // Mocking the behavior of customerService.getCustomerById
        Long customerId = 1L;
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setId(customerId);
        when(customerService.getCustomerById(customerId)).thenReturn(customerDTO);

        ResponseEntity<?> responseEntity = customerController.getCustomerById(customerId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(customerDTO, responseEntity.getBody());
        verify(customerService, times(1)).getCustomerById(customerId);
    }

    @Test
    public void testGetCustomerById_InvalidId_ReturnsNotFound() {
        // Mocking the behavior of customerService.getCustomerById
        Long customerId = 1L;
        when(customerService.getCustomerById(customerId)).thenThrow(new NoSuchElementException("Customer not found"));

        ResponseEntity<?> responseEntity = customerController.getCustomerById(customerId);

        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        assertEquals("Customer not found with ID: " + customerId, responseEntity.getBody());
        verify(customerService, times(1)).getCustomerById(customerId);
    }


    @Test
    public void testGetAllCustomers_ReturnsAllCustomers() {
        // Mocking the behavior of customerService.getAllCustomers
        List<CustomerDTO> allCustomers = List.of(new CustomerDTO(), new CustomerDTO());
        when(customerService.getAllCustomers()).thenReturn(allCustomers);

        ResponseEntity<List<CustomerDTO>> responseEntity = customerController.getAllCustomers();

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(allCustomers, responseEntity.getBody());
        verify(customerService, times(1)).getAllCustomers();
    }

    @Test
    public void testCreateCustomer_ReturnsCreatedCustomer() {
        // Mocking the behavior of customerService.createCustomer
        CustomerDTO customerDTO = new CustomerDTO();
        when(customerService.createCustomer(customerDTO)).thenReturn(customerDTO);

        ResponseEntity<CustomerDTO> responseEntity = customerController.createCustomer(customerDTO);

        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertEquals(customerDTO, responseEntity.getBody());
        verify(customerService, times(1)).createCustomer(customerDTO);
    }

    @Test
    public void testUpdateCustomer_ValidId_ReturnsUpdatedCustomer() {
        // Mocking the behavior of customerService.updateCustomer
        Long customerId = 1L;
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setId(customerId);
        when(customerService.updateCustomer(customerId, customerDTO)).thenReturn(customerDTO);

        ResponseEntity<CustomerDTO> responseEntity = customerController.updateCustomer(customerId, customerDTO);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(customerDTO, responseEntity.getBody());
        verify(customerService, times(1)).updateCustomer(customerId, customerDTO);
    }

    @Test
    public void testUpdateCustomer_InvalidId_ReturnsNotFound() {
        // Mocking the behavior of customerService.updateCustomer to return null
        Long invalidCustomerId = 2L;
        CustomerDTO customerDTO = new CustomerDTO();
        when(customerService.updateCustomer(invalidCustomerId, customerDTO)).thenReturn(null);

        ResponseEntity<CustomerDTO> responseEntity = customerController.updateCustomer(invalidCustomerId, customerDTO);

        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        verify(customerService, times(1)).updateCustomer(invalidCustomerId, customerDTO);
    }

    @Test
    public void testDeleteCustomer_ValidId_ReturnsDeletedMessage() {
        // Mocking the behavior of customerService.deleteCustomer
        Long customerId = 1L;
        when(customerService.deleteCustomer(customerId)).thenReturn(true);

        ResponseEntity<String> responseEntity = customerController.deleteCustomer(customerId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Customer with ID: " + customerId + " has been deleted.", responseEntity.getBody());
        verify(customerService, times(1)).deleteCustomer(customerId);
    }

    @Test
    public void testDeleteCustomer_InvalidId_ReturnsNotFound() {
        // Mocking the behavior of customerService.deleteCustomer to return false
        Long invalidCustomerId = 2L;
        when(customerService.deleteCustomer(invalidCustomerId)).thenReturn(false);

        ResponseEntity<String> responseEntity = customerController.deleteCustomer(invalidCustomerId);

        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        assertEquals("Customer with ID: " + invalidCustomerId + " not found.", responseEntity.getBody());
        verify(customerService, times(1)).deleteCustomer(invalidCustomerId);
    }
}
