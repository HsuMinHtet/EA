package edu.miu.cs.cs544.services;

import edu.miu.cs.cs544.domain.*;
import edu.miu.cs.cs544.DTO.CustomerDTO;
import edu.miu.cs.cs544.repository.CustomerRepository;
import edu.miu.cs.cs544.service.CustomerServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @Mock
    private SecurityContext securityContext;


    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
        SecurityContextHolder.setContext(securityContext);
    }



    @Test
    public void getCustomersById_ExistingId_ShouldReturnCustomerDTO() {
        // Create a sample Customer
        Customer customer = new Customer();
        customer.setId(1L);
        customer.setFirstName("John");
        customer.setLastName("Doe");
        customer.setEmail("john@example.com");

        // Mock behavior of Customer Repository.findById(id)
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));

        // Create a sample CustomerDTO for mapping
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setId(10L);
        customerDTO.setFirstName("John1");
        customerDTO.setLastName("Doe");
        customerDTO.setEmail("john@example.com");

        // Mock the conversion from Admin to AdminDTO
        when(modelMapper.map(any(Customer.class), any())).thenReturn(customerDTO);

        // Test getCustomerById method
        CustomerDTO result = customerService.getCustomerById(1L);

        // Assert the result
        assertEquals("John1", result.getFirstName());
        assertEquals("Doe", result.getLastName());
        assertEquals("john@example.com", result.getEmail());
        // Add more assertions based on your DTO mappings
    }


    @Test
    public void testGetCustomerById_NonExistingId_ThrowsNoSuchElementException() {
        // Arrange
        Long customerId = 2L;

        when(customerRepository.findById(customerId)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(NoSuchElementException.class, () -> customerService.getCustomerById(customerId));
    }


//    @Test
//    public void testGetAllCustomers_ReturnsListOfCustomerDTOs() {
//        // Arrange
//        Customer customer1 = new Customer();
//        customer1.setId(1L);
//        customer1.setFirstName("John");
//        customer1.setLastName("Doe");
//
//        Customer customer2 = new Customer();
//        customer2.setId(2L);
//        customer2.setFirstName("Alice");
//        customer2.setLastName("Smith");
//
//        List<Customer> customerList = Arrays.asList(customer1, customer2);
//
//        when(customerRepository.findAll()).thenReturn(customerList);
//
//        // Act
//        List<CustomerDTO> result = customerService.getAllCustomers();
//
////         Assert
//        assertNotNull(result);
//        assertEquals(2, result.size());
//        assertEquals("John", result.get(0).getFirstName());
//        assertEquals("Doe", result.get(0).getLastName());
//        assertEquals(Long.valueOf(1), result.get(0).getId());
//        assertEquals("Alice", result.get(1).getFirstName());
//        assertEquals("Smith", result.get(1).getLastName());
//        assertEquals(Long.valueOf(2), result.get(1).getId());
//    }


    @Test
    public void createCustomer_WithValidData_ShouldCreateCustomer() {
        // Arrange
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setFirstName("John");
        customerDTO.setLastName("Doe");
        customerDTO.setEmail("john@example.com");

        // Set other required fields in customerDTO
        User user = new User();
        user.setUserName("john");
        user.setUserPass("1234");
        customerDTO.setUser(user);

        Address billingAddress = new Address();
        billingAddress.setLine1("123 Main St");
        billingAddress.setLine2("234 Main St");
        billingAddress.setCity("Springfield");
        billingAddress.setPostalCode("1223");

        State state = new State();
        state.setCode("IL");
        state.setStateName("iowa");

        Country country = new Country();
        country.setCountryName("USA");
        state.setCountry(country);

        billingAddress.setState(state);
        customerDTO.setBillingAddress(billingAddress);

        // Set physical address (similar structure as billingAddress)
        Address physicalAddress = new Address();
        physicalAddress.setLine1("123 Main St");
        physicalAddress.setLine2("234 Main St");
        physicalAddress.setCity("Springfield");
        physicalAddress.setPostalCode("1223");

        State physicalState = new State();
        physicalState.setCode("IL");
        physicalState.setStateName("iowa");

        Country physicalCountry = new Country();
        physicalCountry.setCountryName("USA");
        physicalState.setCountry(physicalCountry);

        physicalAddress.setState(physicalState);
        customerDTO.setPhysicalAddress(physicalAddress);


//        // Stubbing for modelMapper.map method
        when(modelMapper.map(any(), eq(CustomerDTO.class))).thenReturn(customerDTO);

        // Test createAdmin method
        CustomerDTO result = customerService.createCustomer(customerDTO);

        // Assert the result
        assertEquals("John", result.getFirstName());
        assertEquals("Doe", result.getLastName());
        assertEquals("john@example.com", result.getEmail());
        assertEquals(UserType.CLIENT, result.getUser().getType());
        assertNotNull(result.getUser());
    }


    @Test
    public void updateCustomer_WithNonExistingId_ShouldThrowNoSuchElementException() {
        Long nonExistingId = 999L;
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setFirstName("John");
        customerDTO.setLastName("Doe");
        customerDTO.setEmail("john@example.com");

        when(customerRepository.findById(nonExistingId)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> customerService.updateCustomer(nonExistingId, customerDTO));
    }

    @Test
    public void updateCustomer_WithValidData_ShouldNotThrowException() {
        Long existingId = 5L;
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setFirstName("John");
        customerDTO.setLastName("Doe");
        customerDTO.setEmail("john@example.com");

        Optional<Customer> optionalCustomer = Optional.of(new Customer());
        when(customerRepository.findById(existingId)).thenReturn(optionalCustomer);

        // Mock any necessary behaviors for update operation if needed

        assertDoesNotThrow(() -> customerService.updateCustomer(existingId, customerDTO));
    }

    @Test
    public void deleteCustomer_WithExistingId_ShouldReturnTrue() {
        Long existingId = 123L;
        Optional<Customer> optionalCustomer = Optional.of(new Customer());
        when(customerRepository.findById(existingId)).thenReturn(optionalCustomer);

        assertTrue(customerService.deleteCustomer(existingId));
    }

    @Test
    public void deleteCustomer_WithNonExistingId_ShouldReturnFalse() {
        Long nonExistingId = 999L;
        when(customerRepository.findById(nonExistingId)).thenReturn(Optional.empty());

        assertFalse(customerService.deleteCustomer(nonExistingId));
    }


    // Add more test cases as needed for different scenarios
}