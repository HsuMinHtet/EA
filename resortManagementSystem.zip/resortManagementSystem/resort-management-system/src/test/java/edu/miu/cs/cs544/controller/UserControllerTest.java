package edu.miu.cs.cs544.controller;

import edu.miu.cs.cs544.DTO.AuthRequestDTO;
import edu.miu.cs.cs544.DTO.UserDTO;
import edu.miu.cs.cs544.security.JwtService;
import edu.miu.cs.cs544.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Fail.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class UserControllerTest {

    private UserController userController;
    private JwtService jwtService;
    private AuthenticationManager authenticationManager;
    @Mock
    private SecurityContext securityContext;

    @MockBean
    private UserService userService;

    @Mock
    private SecurityContextHolder securityContextHolder;

    @BeforeEach
    void setUp() {
        userService = mock(UserService.class);
        jwtService = mock(JwtService.class);
        authenticationManager = mock(AuthenticationManager.class);
        userController = new UserController(userService, jwtService, authenticationManager);
    }

    @Test
    void testAuthenticateAndGetToken_ValidUser_ReturnsToken() {
        // Mock
        AuthRequestDTO authRequestDTO = new AuthRequestDTO("username", "password");
        Authentication authentication = mock(Authentication.class);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class))).thenReturn(authentication);
        when(jwtService.generateToken("username")).thenReturn("mockedToken");

        // Test
        String token = userController.authenticateAndGetToken(authRequestDTO);

        // Verify
        assertEquals("mockedToken", token);
    }

    @Test
    void testAuthenticateAndGetToken_InvalidUser_ThrowsException() {
        // Mock
        AuthRequestDTO authRequestDTO = new AuthRequestDTO("invalidUsername", "invalidPassword");
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenThrow(UsernameNotFoundException.class);

        // Test & Verify
        try {
            userController.authenticateAndGetToken(authRequestDTO);
        } catch (UsernameNotFoundException e) {
            assertTrue(e instanceof UsernameNotFoundException);
        }
    }

    @Test
    public void testLogout_Successful() {
        try {
            // Mocking the UserController and its dependencies
            UserController userController = mock(UserController.class);

            // Stubbing the SecurityContextHolder clearContext method
            SecurityContextHolder.clearContext();

            // Executing the logout method
            ResponseEntity<String> response = userController.logout();

            // Validating the response
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("Logout successful", response.getBody());
        } catch (Exception e) {
            // Handle any exceptions here
        }
    }

    @Test
    public void testLogout_InternalServerError() {
        try {
            UserController userController = mock(UserController.class);

            // Stubbing the behavior of SecurityContextHolder
            SecurityContextHolder.clearContext(); // This line might not be needed

            // Execute the logout method
            ResponseEntity<String> response = userController.logout();

            // Validate the response
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertEquals("Error occurred during logout", response.getBody());

            // Here, you might not be able to directly verify the clearContext() call
            // Instead, ensure that the behavior after logout is consistent with an unsuccessful logout

            // For example, if there's any state change in SecurityContextHolder, validate it here
            boolean contextCleared = SecurityContextHolder.getContext() == null;

            // Assert that the context is not cleared after the unsuccessful logout attempt
            assertEquals(false, contextCleared, "Context should not be cleared after a failed logout attempt");

        } catch (Exception e) {
            // Handle any exceptions here
        }
    }
    @Test
    void testCreateUser_ValidUser_ReturnsCreatedUser() {
        // Mock
        UserDTO userDTO = new UserDTO();
        when(userService.createUser(any(UserDTO.class))).thenReturn(userDTO);

        // Test
        ResponseEntity<UserDTO> response = userController.createUser(userDTO);

        // Verify
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(userDTO, response.getBody());
    }

    @Test
    void testGetUserById() {
        // Mock data
        Long userId = 1L;
        UserDTO userDTO = new UserDTO(); // Create a sample UserDTO

        // Mock UserService behavior
        when(userService.getUserById(userId)).thenReturn(userDTO);

        // Call the method being tested
        ResponseEntity<UserDTO> response = userController.getUserById(userId);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userDTO, response.getBody());

        // Verify that the UserService method was called once
        verify(userService, times(1)).getUserById(userId);
    }

    private void testGetAllUsers() {
        // Mock data
        List<UserDTO> users = new ArrayList<>(); // Create sample user list

        // Mock UserService behavior
        when(userService.getAllUsers()).thenReturn(users);

        // Call the method being tested
        ResponseEntity<List<UserDTO>> response = userController.getAllUsers();

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(users, response.getBody());

        // Verify that the UserService method was called once
        verify(userService, times(1)).getAllUsers();
    }

    private void testUpdateUser() {
        // Mock data
        Long userId = 1L;
        UserDTO userDTO = new UserDTO(); // Create a sample UserDTO

        // Mock UserService behavior
        when(userService.updateUser(userId, userDTO)).thenReturn(userDTO);

        // Call the method being tested
        ResponseEntity<UserDTO> response = userController.updateUser(userId, userDTO);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userDTO, response.getBody());

        // Verify that the UserService method was called once
        verify(userService, times(1)).updateUser(userId, userDTO);
    }

    private void testDeleteUser() {
        // Mock data
        Long userId = 1L;

        // Mock UserService behavior
        when(userService.deleteUser(userId)).thenReturn(true);

        // Call the method being tested
        ResponseEntity<String> response = userController.deleteUser(userId);

        // Assertions
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("User with ID: " + userId + " has been deleted.", response.getBody());

        // Verify that the UserService method was called once
        verify(userService, times(1)).deleteUser(userId);
    }
    // Ensure to cover edge cases and expected behavior for each method in your tests.
}