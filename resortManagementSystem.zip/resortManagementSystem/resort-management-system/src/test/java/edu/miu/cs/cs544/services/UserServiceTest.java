package edu.miu.cs.cs544.services;

import edu.miu.cs.cs544.DTO.UserDTO;
import edu.miu.cs.cs544.domain.User;
import edu.miu.cs.cs544.repository.UserRepository;
import edu.miu.cs.cs544.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @Mock
    private PasswordEncoder encoder;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetUserById_ExistingId_ReturnsUserDTO() {
        // Arrange
        Long userId = 1L;
        User existingUser = new User();
        existingUser.setId(userId);
        existingUser.setUserName("testUser");
        existingUser.setUserPass("password");

        when(userRepository.findById(userId)).thenReturn(Optional.of(existingUser));

        // Act
        UserDTO result = userService.getUserById(userId);

        // Assert
        assertNotNull(result);
        assertEquals("testUser", result.getUserName());
        assertEquals(encoder.encode("password"), result.getUserPass());
        assertEquals(userId, result.getId());
    }

    @Test
    public void testGetUserById_NonExistingId_ThrowsNoSuchElementException() {
        // Arrange
        Long userId = 2L;

        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(NoSuchElementException.class, () -> userService.getUserById(userId));
    }

    @Test
    public void testGetAllUsers_ReturnsListOfUserDTOs() {
        // Arrange
        User user1 = new User();
        user1.setId(1L);
        user1.setUserName("user1");
        user1.setUserPass("pass1");

        User user2 = new User();
        user2.setId(2L);
        user2.setUserName("user2");
        user2.setUserPass("pass2");

        List<User> userList = Arrays.asList(user1, user2);

        when(userRepository.findAll()).thenReturn(userList);

        // Act
        List<UserDTO> result = userService.getAllUsers();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("user1", result.get(0).getUserName());
        assertEquals(encoder.encode("pass1"), result.get(0).getUserPass());
        assertEquals(Long.valueOf(1), result.get(0).getId());
        assertEquals("user2", result.get(1).getUserName());
        assertEquals(encoder.encode("pass2"), result.get(1).getUserPass());
        assertEquals(Long.valueOf(2), result.get(1).getId());
    }


    // Test cases for createUser, updateUser, and deleteUser methods can be added similarly
    // Ensure to cover positive and negative scenarios for these methods


    // Existing User
    private User getMockUser(Long id, String username, String password) {
        User user = new User();
        user.setId(id);
        user.setUserName(username);
        user.setUserPass(password);
        return user;
    }

    @Test
    public void testCreateUser_ValidUser_ReturnsCreatedUserDTO() {
        // Arrange
        UserDTO userDTO = new UserDTO();
        userDTO.setUserName("testUser");
        userDTO.setUserPass("password");

        when(userRepository.save(any(User.class))).thenReturn(getMockUser(100L, "testUser", "password"));

        // Act
        UserDTO result = userService.createUser(userDTO);

        // Assert
        assertNotNull(result);
        assertEquals("testUser", result.getUserName());
        assertEquals(encoder.encode("password"), result.getUserPass());
        assertTrue(result.getActive());
    }

    @Test
    public void testUpdateUser_ExistingUser_ReturnsUpdatedUserDTO() {
        // Arrange
        Long userId = 1L;
        UserDTO userDTO = new UserDTO();
        userDTO.setId(userId);
        userDTO.setUserName("updatedUser");
        userDTO.setUserPass("updatedPassword");

        when(userRepository.findById(userId)).thenReturn(Optional.of(getMockUser(userId, "testUser", "password")));
        when(userRepository.save(any(User.class))).thenReturn(getMockUser(userId, "updatedUser", "updatedPassword"));

        // Act
        UserDTO result = userService.updateUser(userId, userDTO);

        // Assert
        assertNotNull(result);
        assertEquals(userId, result.getId());
        assertEquals("updatedUser", result.getUserName());
        assertEquals("updatedPassword", result.getUserPass());
    }

    @Test
    public void testUpdateUser_NonExistingUser_ReturnsNull() {
        // Arrange
        Long userId = 2L;
        UserDTO userDTO = new UserDTO();
        userDTO.setId(userId);
        userDTO.setUserName("updatedUser");
        userDTO.setUserPass("updatedPassword");

        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // Act
        UserDTO result = userService.updateUser(userId, userDTO);

        // Assert
        assertNull(result);
    }

    @Test
    public void testDeleteUser_ExistingUser_DeletesUserAndReturnsTrue() {
        // Arrange
        Long userId = 1L;

        when(userRepository.findById(userId)).thenReturn(Optional.of(getMockUser(userId, "testUser", "password")));

        // Act
        boolean result = userService.deleteUser(userId);

        // Assert
        assertTrue(result);
        verify(userRepository, times(1)).delete(any(User.class));
    }

    @Test
    public void testDeleteUser_NonExistingUser_ReturnsFalse() {
        // Arrange
        Long userId = 2L;

        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // Act
        boolean result = userService.deleteUser(userId);

        // Assert
        assertFalse(result);
        verify(userRepository, never()).delete(any(User.class));
    }
}