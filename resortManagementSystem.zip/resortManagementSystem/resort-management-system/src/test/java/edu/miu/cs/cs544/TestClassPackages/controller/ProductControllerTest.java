package edu.miu.cs.cs544.TestClassPackages.controller;

import edu.miu.cs.cs544.DTO.ProductDTO;
import edu.miu.cs.cs544.controller.ProductController;
import edu.miu.cs.cs544.service.ProductService;
import edu.miu.cs.cs544.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ProductController.class)
@ExtendWith({SpringExtension.class, MockitoExtension.class})
@AutoConfigureMockMvc (addFilters = false)
public class ProductControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService productService;
    @MockBean
    private UserService userService;

    @Test
    void getProductById_ProductExists() throws Exception {
        // Mock a ProductDTO
        ProductDTO mockProductDTO = new ProductDTO(/* Initialize with sample data */);

        // Mock the productService to return the mockProductDTO when getProductById is called with any Long argument
        when(productService.getProductById(anyLong())).thenReturn(mockProductDTO);

        // Perform a GET request to the /api/products/{id} endpoint
        mockMvc.perform(MockMvcRequestBuilders.get("/api/products/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.property1").value(mockProductDTO.getName())) // Update with actual property names
                .andExpect(jsonPath("$.property2").value(mockProductDTO.getNightlyRate()))
                .andReturn();
    }

    @Test
    void getProductById_ProductDoesNotExist() throws Exception {
        // Mock that the productService returns null (product not found)
        when(productService.getProductById(anyLong())).thenReturn(null);

        // Perform a GET request to the /api/products/{id} endpoint
        mockMvc.perform(MockMvcRequestBuilders.get("/api/products/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andReturn();
    }
}